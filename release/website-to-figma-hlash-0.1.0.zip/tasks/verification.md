# Verification record

By Hla.Sh · 29 October 2026 · Development build 0.1.0

Latest local npm run check: passed with 37 unit/API tests, 9 real Chromium tests, formatting, TypeScript and plugin build. No tests skipped. This includes insertion-cancellation source retention and offline imports without reference screenshots.

## Executed checks

- Shared scene validation: versions, JSON safety, cycles, array subclasses/sparse tuples, finite geometry, counts, depth, references, styled text ranges and PNG headers.
- Network boundary: unsafe schemes, credentials, private/metadata/reserved addresses, mixed DNS answers, per-capture proxy authentication, DNS pinning and denied HTTPS tunnels.
- Local API: bearer authentication, foreign origins, session-code isolation from null-origin requests, bounded input, retry idempotency/conflicts, capture cancellation and late-result suppression.
- Real browser capture: desktop/mobile visibility, 3/1-column grid changes, English/Arabic text, logical RTL alignment, bold ranges, original PNG/SVG assets, sanitized SVG, margins, inherited backgrounds, source screenshots, repeated geometry, selected sections, capture caps, instability and cancellation.
- Real browser interface: the dashboard completes an owned demo capture and download; the built plugin UI connects, captures, reviews missing fonts, and sends explicit import settings. Its host message boundary is simulated in this browser test.
- Public URL smoke test: example.com captured at desktop/mobile widths through the authenticated egress proxy.

## Actual Figma renderer evidence

[Validation file](https://www.figma.com/design/qTgTA125JqaCSg4Yo6xxdJ)

The same compiled native renderer used by the plugin was executed against the captured feature section. The latest successful routine created 11 editable text nodes, 7 Auto Layout containers, 17 bound variables, 5 text styles, 1 main card component, and 3 instances.

Checks passed:

- Component replacement preserved 3 columns in 1 row and instance order.
- The native grid fit after resizing the frame to 1000px.
- A substantially longer heading increased the instance height from approximately 245px to 560px; restoring the text restored the layout.
- Updating a bound color variable updated an instance paint; the original value was restored.
- Inline label properties grew to their own content widths.
- A separate native asset check imported one original PNG and one SVG vector with no conversion notices.

Full returned IDs, source mappings, checks and geometry are in [native-verification.json](native-verification.json). Native validation code is in tests/native-validation.ts.

The checks found and fixed real defects before passing: use of a browser-only URL global in Figma main code; extra/manual grid rows during component replacement; fixed grid-child widths during resize; text resizing reset by geometry/component operations; fixed-width component labels; and source preview frame bounds that omitted page margins/background.

## Fidelity limits observed

Arial was not available in the connected Figma environment. The test explicitly allowed Inter and returned substitution notices. Native line metrics and final height consequently differ from the source. The latest saved comparison reports 7.53% of pixels above its threshold and different heights (source approximately 497px, Figma approximately 510px). This is a diagnostic, not a 92.47% accuracy claim. Earlier comparison numbers are superseded. Artifacts are in output/validation/final-comparison.

Final review found two further component regressions: different images/crops could be grouped without image overrides, and nested families could invalidate one another during replacement. The fixes preserve asset/crop and typography identity and select non-overlapping outer families. Reproduction tests failed before the fixes and pass afterward; an owned browser fixture covers nested cards/buttons and distinct red/blue images. The additional native Figma regression was stopped by the Starter plan's tool-call limit, so that specific native rerun remains pending. Earlier native resize/edit/variable/asset evidence remains available.

The current release does not meet the roadmap's universal fidelity ambition or its proposed broad-corpus thresholds. One owned page and a small public smoke test are not the 30+ fixture benchmark or human cleanup study proposed in the plan. Complex effects, precise typography, more CSS coverage and held-out website evaluation remain open.

## Packaging and remaining manual check

The development manifest, code and UI are built locally. Figma-assigned plugin identity and loading the distributed development manifest in the user's Desktop environment still need the setup described in README.md. The actual renderer is verified; the complete installed plugin main/UI lifecycle has not been exercised through a user-installed development plugin.

CI configuration is included. Local commands are run here; remote CI execution has not occurred because no remote repository/push was requested.
