import http from 'node:http';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { captureHtml, captureUrl } from '../capture/capture.js';
import { analyzeScene, flatten } from '../core/analysis.js';
import { comparePng, compareGeometry, type GeometryRecord } from '../quality/compare.js';
import {
  createJobManager,
  parseCaptureRequest,
  HttpError,
  type CaptureRunner,
  type Job,
} from './jobs.js';
import { dashboard } from './dashboard.js';

const defaultRunner: CaptureRunner = async (request, signal, onProgress) => {
  const options = {
    widths: request.widths,
    height: request.height,
    theme: request.theme,
    signal,
    onProgress,
    selector: request.selector,
  };
  return request.demo
    ? captureHtml(
        await readFile(new URL('../../fixtures/reference.html', import.meta.url), 'utf8'),
        options,
      )
    : captureUrl(request.url!, options);
};
const summary = (job: Job) => ({
  id: job.id,
  state: job.state,
  stage: job.stage,
  createdAt: job.createdAt,
  error: job.error,
  ...(job.scene ? { analysis: analyzeScene(job.scene) } : {}),
});
async function body(req: http.IncomingMessage, max = 12 * 1024 * 1024): Promise<unknown> {
  let length = 0;
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    length += chunk.length;
    if (length > max) throw new HttpError(413, 'Request body exceeds limit.');
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'Invalid JSON request.');
  }
}

export async function createLocalService(options: { port?: number; runner?: CaptureRunner } = {}) {
  const token = randomBytes(24).toString('hex');
  const jobs = createJobManager(options.runner ?? defaultRunner);
  let origin = '';
  const server = http.createServer(async (req, res) => {
    const send = (status: number, data: unknown) => {
      res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
      });
      res.end(JSON.stringify(data));
    };
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    try {
      if (req.headers.host !== new URL(origin).host)
        throw new HttpError(403, 'Invalid local service host.');
      const requestOrigin = req.headers.origin;
      if (
        requestOrigin &&
        !['null', 'https://www.figma.com', 'https://figma.com', origin].includes(requestOrigin)
      )
        throw new HttpError(403, 'Origin is not allowed.');
      if (requestOrigin) {
        res.setHeader('Access-Control-Allow-Origin', requestOrigin);
        res.setHeader('Vary', 'Origin');
      }
      if (req.method === 'OPTIONS') {
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
        res.setHeader(
          'Access-Control-Allow-Headers',
          'Authorization, Content-Type, Idempotency-Key',
        );
        res.writeHead(204);
        res.end();
        return;
      }
      const url = new URL(req.url ?? '/', origin);
      if (req.method === 'GET' && url.pathname === '/') {
        if (requestOrigin && requestOrigin !== origin)
          throw new HttpError(403, 'Open the local dashboard directly to view the session code.');
        res.setHeader(
          'Content-Security-Policy',
          "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        );
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store',
        });
        res.end(dashboard(token));
        return;
      }
      const authorization = Buffer.from(req.headers.authorization ?? '');
      const expected = Buffer.from(`Bearer ${token}`);
      if (authorization.length !== expected.length || !timingSafeEqual(authorization, expected))
        throw new HttpError(401, 'Enter the current session code from the local service.');
      if (url.pathname === '/health' && req.method === 'GET') {
        send(200, { status: 'ready', version: '0.1.0', author: 'Hla.Sh' });
        return;
      }
      if (url.pathname === '/jobs' && req.method === 'POST') {
        const request = parseCaptureRequest(await body(req, 8192));
        const key = req.headers['idempotency-key'];
        if (Array.isArray(key)) throw new HttpError(400, 'Invalid retry key.');
        send(202, summary(jobs.create(request, key)));
        return;
      }
      const match = url.pathname.match(/^\/jobs\/([a-f0-9-]{36})(?:\/(scene|compare|remove))?$/);
      if (!match) throw new HttpError(404, 'Endpoint not found.');
      const job = jobs.get(match[1]!);
      if (req.method === 'DELETE') {
        if (match[2] === 'remove') {
          jobs.remove(job.id);
          send(200, { removed: true });
        } else send(200, summary(jobs.cancel(job.id)));
        return;
      }
      if (req.method === 'GET' && !match[2]) {
        send(200, summary(job));
        return;
      }
      if (!job.scene || job.state !== 'ready') throw new HttpError(409, 'Capture is not ready.');
      if (req.method === 'GET' && match[2] === 'scene') {
        send(200, job.scene);
        return;
      }
      if (req.method === 'POST' && match[2] === 'compare') {
        const data = (await body(req)) as { screenId?: unknown; png?: unknown; geometry?: unknown };
        if (
          !data ||
          typeof data.screenId !== 'string' ||
          typeof data.png !== 'string' ||
          data.png.length > 10 * 1024 * 1024 ||
          !/^[A-Za-z0-9+/]+={0,2}$/.test(data.png) ||
          data.png.length % 4
        )
          throw new HttpError(400, 'Choose a screen and a valid PNG export.');
        const screen = job.scene.screens.find((s) => s.id === data.screenId);
        if (!screen?.screenshot) throw new HttpError(404, 'Source screen was not found.');
        const comparison = await comparePng(
          Buffer.from(screen.screenshot, 'base64'),
          Buffer.from(data.png, 'base64'),
        );
        let geometry;
        if (data.geometry !== undefined) {
          if (!Array.isArray(data.geometry) || data.geometry.length > 12000)
            throw new HttpError(400, 'Invalid geometry report.');
          for (const n of data.geometry) {
            if (
              !n ||
              typeof n.sourceId !== 'string' ||
              !n.bounds ||
              !['x', 'y', 'width', 'height'].every((k) => Number.isFinite(n.bounds[k])) ||
              (n.text !== undefined && typeof n.text !== 'string')
            )
              throw new HttpError(400, 'Invalid geometry entry.');
          }
          geometry = compareGeometry(
            flatten(screen.root).map((n) => ({
              sourceId: n.id,
              bounds: n.bounds,
              ...(n.text ? { text: n.text.characters } : {}),
            })),
            data.geometry as GeometryRecord[],
          );
        }
        send(200, {
          visual: {
            ...comparison,
            diff: comparison.diff.toString('base64'),
            overlay: comparison.overlay.toString('base64'),
          },
          geometry,
        });
        return;
      }
      throw new HttpError(404, 'Endpoint not found.');
    } catch (error) {
      if (!res.headersSent)
        send(error instanceof HttpError ? error.status : 500, {
          error: error instanceof Error ? error.message.slice(0, 800) : 'Request failed.',
        });
      else res.end();
    }
  });
  server.requestTimeout = 100000;
  server.headersTimeout = 10000;
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(options.port ?? 4017, '127.0.0.1', resolve);
  });
  const address = server.address() as { port: number };
  origin = `http://127.0.0.1:${address.port}`;
  return {
    url: origin,
    token,
    close: async () => {
      jobs.close();
      server.closeAllConnections();
      await new Promise<void>((resolve) => server.close(() => resolve()));
    },
  };
}
