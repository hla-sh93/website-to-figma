import type { SceneNode, SceneIssue } from '../core/scene.js';
/** Executed in Chromium. All coordinates remain in the source document space. */
export function collect(selector: string | undefined): {
  root: SceneNode;
  issues: SceneIssue[];
  sources: { nodeId: string; kind: 'image' | 'svg'; url: string; width: number; height: number }[];
} {
  const issues: SceneIssue[] = [],
    sources: {
      nodeId: string;
      kind: 'image' | 'svg';
      url: string;
      width: number;
      height: number;
    }[] = [];
  let count = 0;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = colorCanvas.height = 1;
  const colorContext = colorCanvas.getContext('2d', { willReadFrequently: true })!;
  const colorCache = new Map<string, { r: number; g: number; b: number; a: number }>();
  const color = (s: string) => {
    const cached = colorCache.get(s);
    if (cached) return cached;
    colorContext.clearRect(0, 0, 1, 1);
    colorContext.fillStyle = s;
    colorContext.fillRect(0, 0, 1, 1);
    const values = colorContext.getImageData(0, 0, 1, 1).data;
    const value = {
      r: values[0]! / 255,
      g: values[1]! / 255,
      b: values[2]! / 255,
      a: values[3]! / 255,
    };
    colorCache.set(s, value);
    return value;
  };
  const px = (s: string) => parseFloat(s) || 0;
  const alignment = (c: CSSStyleDeclaration): 'left' | 'right' | 'center' | 'justify' =>
    c.textAlign === 'center'
      ? 'center'
      : c.textAlign === 'justify'
        ? 'justify'
        : c.textAlign === 'right' ||
            (c.textAlign === 'start' && c.direction === 'rtl') ||
            (c.textAlign === 'end' && c.direction !== 'rtl')
          ? 'right'
          : 'left';
  const issue = (id: string, code: string, message: string) => {
    if (issues.length < 900) issues.push({ code, severity: 'warning', message, nodeId: id });
  };
  const build = (el: Element, path: string, depth: number): SceneNode | null => {
    const c = getComputedStyle(el),
      r = el.getBoundingClientRect();
    if (
      c.display === 'none' ||
      c.visibility === 'hidden' ||
      !r.width ||
      !r.height ||
      r.top + scrollY >= 16000
    )
      return null;
    if (++count > 2200 || depth > 65) throw new Error('Capture DOM node/depth budget exceeded');
    const key = el.getAttribute('data-figma-id') || el.id || path,
      id = path;
    const n: SceneNode = {
      id,
      name: (
        el.getAttribute('aria-label') ||
        el.getAttribute('data-figma-id') ||
        el.id ||
        (
          {
            HEADER: 'Header',
            NAV: 'Navigation',
            MAIN: 'Main',
            SECTION: 'Section',
            ARTICLE: 'Card',
            FOOTER: 'Footer',
            H1: 'Heading',
            H2: 'Heading',
            H3: 'Heading',
            P: 'Description',
            BUTTON: 'Button',
          } as Record<string, string>
        )[el.tagName] ||
        el.classList[0] ||
        el.tagName.toLowerCase()
      )
        .replace(/\s+/g, ' ')
        .slice(0, 100),
      kind: 'frame',
      source: { tag: el.tagName.toLowerCase(), key },
      bounds: { x: r.left + scrollX, y: r.top + scrollY, width: r.width, height: r.height },
      style: {
        opacity: px(c.opacity),
        background: color(c.backgroundColor),
        radius: [
          px(c.borderTopLeftRadius),
          px(c.borderTopRightRadius),
          px(c.borderBottomRightRadius),
          px(c.borderBottomLeftRadius),
        ],
        clipContent: ['hidden', 'clip'].includes(c.overflow),
      },
      children: [],
      position: c.position === 'absolute' || c.position === 'fixed' ? 'absolute' : 'flow',
    };
    if (px(c.borderTopWidth))
      n.style.border = { width: px(c.borderTopWidth), color: color(c.borderTopColor) };
    if (c.transform !== 'none')
      issue(
        id,
        'transform',
        'Transform is retained as measured bounds; editable transform and rotated child geometry are approximated.',
      );
    if (c.boxShadow !== 'none') {
      const m = c.boxShadow.match(
        /^(rgba?\([^)]+\)) (-?[\d.]+)px (-?[\d.]+)px ([\d.]+)px (-?[\d.]+)px$/,
      );
      if (m)
        n.style.shadow = [
          { color: color(m[1]!), x: px(m[2]!), y: px(m[3]!), blur: px(m[4]!), spread: px(m[5]!) },
        ];
      else
        issue(
          id,
          'unsupported-effect',
          'Complex or inset shadow is not represented by editable style.',
        );
    }
    if (c.backgroundImage !== 'none' || c.filter !== 'none')
      issue(
        id,
        'unsupported-effect',
        'Background image/gradient, shadow, or filter is not represented by editable style.',
      );
    for (const pseudo of ['::before', '::after']) {
      const s = getComputedStyle(el, pseudo);
      if (s.content !== 'none' && s.content !== 'normal')
        issue(
          id,
          'pseudo-content',
          'Generated pseudo content is visible in screenshot but not editable.',
        );
    }
    if (['CANVAS', 'VIDEO', 'IFRAME'].includes(el.tagName))
      issue(id, 'unsupported-media', 'Dynamic media is present only in the source screenshot.');
    if (el instanceof HTMLImageElement) {
      n.kind = 'image';
      sources.push({
        nodeId: id,
        kind: 'image',
        url: el.currentSrc || el.src,
        width: el.naturalWidth,
        height: el.naturalHeight,
      });
      n.image = {
        fit: ['cover', 'contain'].includes(c.objectFit)
          ? (c.objectFit as 'cover' | 'contain')
          : 'fill',
        position: c.objectPosition
          .split(' ')
          .map((v) => px(v) / 100)
          .slice(0, 2) as [number, number],
      };
      return n;
    }
    if (el instanceof SVGSVGElement) {
      const clone = el.cloneNode(true) as Element;
      clone
        .querySelectorAll('script,foreignObject,style,animate,set,animateTransform')
        .forEach((e) => e.remove());
      for (const e of [clone, ...clone.querySelectorAll('*')])
        for (const a of [...e.attributes])
          if (
            a.name.startsWith('on') ||
            (/href/i.test(a.name) && !a.value.startsWith('#')) ||
            /url\((?!["']?#)/i.test(a.value)
          )
            e.removeAttribute(a.name);
      n.kind = 'svg';
      sources.push({
        nodeId: id,
        kind: 'svg',
        url: 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(clone.outerHTML))),
        width: r.width,
        height: r.height,
      });
      return n;
    }
    const hasAsset = !!el.querySelector('svg,img,canvas,video,iframe');
    const hasBlock = [...el.children].some(
      (e) =>
        !['inline', 'inline-block', 'contents'].includes(getComputedStyle(e).display) &&
        e.tagName !== 'BR',
    );
    if (!hasBlock && !hasAsset && (el.textContent ?? '').trim()) {
      n.kind = 'text';
      let characters = '';
      const runs: NonNullable<NonNullable<SceneNode['text']>['runs']> = [];
      const add = (node: Node) => {
        if (node instanceof Element) {
          if (getComputedStyle(node).display === 'none') return;
          if (node.tagName === 'BR') {
            characters += '\n';
            return;
          }
          node.childNodes.forEach(add);
          return;
        }
        if (node.nodeType !== Node.TEXT_NODE) return;
        const style = getComputedStyle(node.parentElement!);
        let s = node.textContent ?? '';
        if (!style.whiteSpace.startsWith('pre')) s = s.replace(/\s+/g, ' ');
        if (!characters || characters.endsWith(' ') || characters.endsWith('\n'))
          s = s.replace(/^ +/, '');
        if (style.textTransform === 'uppercase') s = s.toUpperCase();
        if (style.textTransform === 'lowercase') s = s.toLowerCase();
        if (style.textTransform === 'capitalize')
          s = s.replace(/\b\p{L}/gu, (x) => x.toUpperCase());
        const start = characters.length;
        characters += s;
        if (s)
          runs.push({
            start,
            end: characters.length,
            fontFamily: style.fontFamily,
            fontStyle: style.fontStyle,
            fontWeight: px(style.fontWeight) || 400,
            fontSize: px(style.fontSize),
            color: color(style.color),
          });
      };
      el.childNodes.forEach(add);
      characters = characters.trimEnd();
      runs.forEach((t) => (t.end = Math.min(t.end, characters.length)));
      n.text = {
        characters,
        fontFamily: c.fontFamily,
        fontStyle: c.fontStyle,
        fontWeight: px(c.fontWeight) || 400,
        fontSize: px(c.fontSize),
        lineHeight: c.lineHeight === 'normal' ? px(c.fontSize) * 1.2 : px(c.lineHeight),
        letterSpacing: px(c.letterSpacing),
        color: color(c.color),
        align: alignment(c),
        direction: c.direction === 'rtl' ? 'rtl' : 'ltr',
        sizing: c.display === 'inline' ? 'inline' : 'block',
        runs: runs.filter((t) => t.end > t.start),
      };
      const decorated =
        (n.style.background?.a ?? 0) > 0 ||
        !!n.style.border ||
        !!n.style.shadow ||
        [c.paddingTop, c.paddingRight, c.paddingBottom, c.paddingLeft].some((v) => px(v) > 0);
      if (decorated) {
        const child: SceneNode = {
          ...n,
          id: id + '/text',
          name: n.name + ' text',
          source: { tag: '#text' },
          style: { opacity: 1 },
          children: [],
          bounds: {
            x: n.bounds.x + px(c.borderLeftWidth) + px(c.paddingLeft),
            y: n.bounds.y + px(c.borderTopWidth) + px(c.paddingTop),
            width: Math.max(
              0,
              r.width -
                px(c.borderLeftWidth) -
                px(c.borderRightWidth) -
                px(c.paddingLeft) -
                px(c.paddingRight),
            ),
            height: Math.max(
              0,
              r.height -
                px(c.borderTopWidth) -
                px(c.borderBottomWidth) -
                px(c.paddingTop) -
                px(c.paddingBottom),
            ),
          },
        };
        delete n.text;
        n.kind = 'frame';
        n.children = [child];
      } else return n;
    }
    if (!n.children.length)
      n.children = [...el.children]
        .map((e, i) => build(e, path + '/' + i, depth + 1))
        .filter((v): v is SceneNode => !!v);
    // Text nodes between block/asset children need their own measured editable nodes.
    if (hasBlock || hasAsset) {
      let index = 0;
      for (const node of el.childNodes) {
        const i = index++;
        if (node.nodeType !== Node.TEXT_NODE || !node.textContent?.trim()) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const b = range.getBoundingClientRect();
        if (!b.width || !b.height) continue;
        const characters = node.textContent.replace(/\s+/g, ' ').trim();
        n.children.push({
          id: id + '/direct-' + i,
          name: 'text',
          kind: 'text',
          source: { tag: '#text' },
          bounds: { x: b.x + scrollX, y: b.y + scrollY, width: b.width, height: b.height },
          style: { opacity: 1 },
          children: [],
          position: 'flow',
          text: {
            characters,
            fontFamily: c.fontFamily,
            fontStyle: c.fontStyle,
            fontWeight: px(c.fontWeight) || 400,
            fontSize: px(c.fontSize),
            lineHeight: c.lineHeight === 'normal' ? px(c.fontSize) * 1.2 : px(c.lineHeight),
            letterSpacing: px(c.letterSpacing),
            color: color(c.color),
            align: alignment(c),
            direction: c.direction === 'rtl' ? 'rtl' : 'ltr',
            sizing: 'inline',
          },
        });
      }
      n.children.sort((a, b) => {
        const ai = a.id.includes('/direct-')
          ? Number(a.id.split('/direct-')[1])
          : [...el.childNodes].indexOf(el.children[Number(a.id.split('/').at(-1))]!);
        const bi = b.id.includes('/direct-')
          ? Number(b.id.split('/direct-')[1])
          : [...el.childNodes].indexOf(el.children[Number(b.id.split('/').at(-1))]!);
        return ai - bi;
      });
    }
    const flex = c.display.includes('flex'),
      grid = c.display.includes('grid'),
      horizontal = flex && c.flexDirection.startsWith('row');
    const align =
      c.alignItems === 'center'
        ? 'center'
        : c.alignItems.includes('end')
          ? 'end'
          : c.alignItems === 'stretch'
            ? 'stretch'
            : 'start';
    let gap = px(c.gap);
    if (!flex && !grid && n.children.length > 1) {
      const gaps = n.children
        .slice(1)
        .map((x, i) => x.bounds.y - (n.children[i]!.bounds.y + n.children[i]!.bounds.height));
      if (gaps.every((g) => g >= 0) && Math.max(...gaps) - Math.min(...gaps) < 1) gap = gaps[0]!;
      else
        issue(
          id,
          'margin-spacing',
          'Block margin/collapse spacing retained in source coordinates; auto layout is approximate.',
        );
    }
    n.layout = {
      mode: grid ? 'grid' : horizontal ? 'horizontal' : 'vertical',
      gap,
      rowGap: px(c.rowGap),
      padding: [px(c.paddingTop), px(c.paddingRight), px(c.paddingBottom), px(c.paddingLeft)],
      align,
      justify:
        c.justifyContent === 'space-between'
          ? 'space-between'
          : c.justifyContent === 'center'
            ? 'center'
            : c.justifyContent.includes('end')
              ? 'end'
              : 'start',
      wrap: c.flexWrap === 'wrap',
      widthSizing:
        el.parentElement &&
        Math.abs(
          r.width -
            (el.parentElement.getBoundingClientRect().width -
              px(getComputedStyle(el.parentElement).paddingLeft) -
              px(getComputedStyle(el.parentElement).paddingRight) -
              px(getComputedStyle(el.parentElement).borderLeftWidth) -
              px(getComputedStyle(el.parentElement).borderRightWidth)),
        ) < 1
          ? 'fill'
          : 'fixed',
      heightSizing:
        !(el as HTMLElement).style.height && c.display !== 'inline' && n.children.length > 0
          ? 'hug'
          : 'fixed',
      ...(grid ? { columns: c.gridTemplateColumns.split(' ').filter(Boolean).length } : {}),
    };
    return n;
  };
  const el = selector ? document.querySelector(selector) : document.body;
  if (!el) throw new Error('Capture selector was not found');
  const root = build(el, 'root', 0);
  if (!root) throw new Error('Capture selector is not visible');
  return { root, issues, sources };
}
