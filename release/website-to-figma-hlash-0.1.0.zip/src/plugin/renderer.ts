import {
  validateScene,
  type Layout,
  type ScenePackage,
  type SceneNode,
  type TextSpec,
  type RGBA,
} from '../core/scene.js';
import { createComponents } from './components.js';

export type FontFace = { family: string; style: string };
type NativeNode = FrameNode | TextNode | RectangleNode;
export type FontResolution = { font: FontFace; exact: boolean };
export type RenderOptions = {
  fontPolicy?: 'stop' | 'substitute';
  fallbackFamily?: string;
  foundations?: boolean;
  components?: boolean;
  metadata?: boolean;
  isCancelled?: () => boolean;
  onProgress?: (done: number, total: number) => void;
};
export type RenderIssue = { code: string; message: string; sourceId?: string; nodeId?: string };
export type RenderResult = {
  containerId: string;
  screenIds: string[];
  createdNodeIds: string[];
  mapping: Record<string, string>;
  issues: RenderIssue[];
  stats: {
    text: number;
    images: number;
    vectors: number;
    autoLayout: number;
    fixedFrames: number;
    variables: number;
    textStyles: number;
    components: number;
    instances: number;
  };
};

const normal = (s: string) => s.toLowerCase().replace(/[\s_-]/g, '');
const family = (s: string) =>
  s
    .split(',')[0]!
    .trim()
    .replace(/^["']|["']$/g, '');
export function captureHost(url: string): string {
  return /^https?:\/\//i.test(url)
    ? url
        .replace(/^https?:\/\//i, '')
        .split(/[/?#]/)[0]!
        .replace(/[^a-zA-Z0-9.:[\]-]/g, '')
    : 'Owned fixture';
}
function faceWeight(style: string): number {
  const s = normal(style);
  if (s.includes('thin')) return 100;
  if (s.includes('extralight') || s.includes('ultralight')) return 200;
  if (s.includes('light')) return 300;
  if (s.includes('medium')) return 500;
  if (s.includes('semibold') || s.includes('demibold')) return 600;
  if (s.includes('extrabold') || s.includes('ultrabold')) return 800;
  if (s.includes('black') || s.includes('heavy')) return 900;
  if (s.includes('bold')) return 700;
  return 400;
}
export function resolveFont(
  spec: Pick<TextSpec, 'fontFamily' | 'fontStyle' | 'fontWeight'>,
  available: FontFace[],
  fallback = 'Inter',
): FontResolution {
  const requested = family(spec.fontFamily);
  const italic = /italic|oblique/i.test(spec.fontStyle);
  let candidates = available.filter((f) => normal(f.family) === normal(requested));
  const sameFamily = candidates.length > 0;
  if (!candidates.length)
    candidates = available.filter((f) => normal(f.family) === normal(fallback));
  if (!candidates.length)
    throw new Error(
      `No usable editor font for ${requested}. Enable the font or choose an available fallback.`,
    );
  candidates.sort(
    (a, b) =>
      Math.abs(faceWeight(a.style) - spec.fontWeight) -
      Math.abs(faceWeight(b.style) - spec.fontWeight) +
      ((/italic|oblique/i.test(a.style) !== italic ? 2000 : 0) -
        (/italic|oblique/i.test(b.style) !== italic ? 2000 : 0)),
  );
  const font = candidates[0]!;
  return {
    font,
    exact:
      sameFamily &&
      faceWeight(font.style) === spec.fontWeight &&
      /italic|oblique/i.test(font.style) === italic,
  };
}

export function decodeBase64(value: string): Uint8Array {
  if (!value || value.length % 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(value))
    throw new Error('Invalid base64 asset.');
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const bytes = new Uint8Array(
    (value.length / 4) * 3 - (value.endsWith('==') ? 2 : value.endsWith('=') ? 1 : 0),
  );
  let accumulator = 0,
    bits = 0,
    index = 0;
  for (const c of value) {
    if (c === '=') break;
    accumulator = (accumulator << 6) | alphabet.indexOf(c);
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      bytes[index++] = (accumulator >> bits) & 255;
    }
  }
  return bytes;
}
const defaultLayout: Layout = {
  mode: 'none',
  gap: 0,
  padding: [0, 0, 0, 0],
  align: 'start',
  justify: 'start',
  wrap: false,
  widthSizing: 'fixed',
  heightSizing: 'fixed',
};
export function deriveLayout(node: SceneNode): Layout {
  const layout = {
    ...(node.layout ?? defaultLayout),
    padding: [...(node.layout?.padding ?? [0, 0, 0, 0])] as Layout['padding'],
  };
  const children = node.children.filter((n) => n.position !== 'absolute');
  if (layout.mode === 'grid' || layout.mode === 'none' || layout.wrap || children.length < 2)
    return layout;
  const vertical = layout.mode === 'vertical';
  const gaps = children
    .slice(1)
    .map((n, i) =>
      vertical
        ? n.bounds.y - children[i]!.bounds.y - children[i]!.bounds.height
        : n.bounds.x - children[i]!.bounds.x - children[i]!.bounds.width,
    );
  if (gaps.some((g) => g < -1)) return { ...layout, mode: 'none' };
  const min = Math.min(...gaps),
    max = Math.max(...gaps);
  if (max - min <= 1) layout.gap = Math.max(0, gaps.reduce((a, b) => a + b, 0) / gaps.length);
  return layout;
}
function allNodes(pkg: ScenePackage): SceneNode[] {
  const result: SceneNode[] = [];
  const visit = (n: SceneNode) => {
    result.push(n);
    n.children.forEach(visit);
  };
  pkg.screens.forEach((s) => visit(s.root));
  return result;
}
const rgb = ({ r, g, b }: RGBA) => ({ r, g, b });
const solid = (c: RGBA): SolidPaint => ({ type: 'SOLID', color: rgb(c), opacity: c.a });
const fontKey = (s: Pick<TextSpec, 'fontFamily' | 'fontStyle' | 'fontWeight'>) =>
  `${s.fontFamily}|${s.fontStyle}|${s.fontWeight}`;

export async function preflightFonts(api: PluginAPI, pkg: ScenePackage, fallback = 'Inter') {
  const available = (await api.listAvailableFontsAsync()).map((f) => f.fontName);
  const requests = new Map<string, Pick<TextSpec, 'fontFamily' | 'fontStyle' | 'fontWeight'>>();
  for (const node of allNodes(pkg)) {
    if (!node.text) continue;
    requests.set(fontKey(node.text), node.text);
    for (const run of node.text.runs ?? []) {
      const request = { ...node.text, ...run };
      requests.set(fontKey(request), request);
    }
  }
  const resolutions = new Map<string, FontResolution>();
  const missing: { requested: string; replacement: FontFace }[] = [];
  for (const [key, spec] of requests) {
    const resolved = resolveFont(spec, available, fallback);
    resolutions.set(key, resolved);
    if (!resolved.exact)
      missing.push({
        requested: `${family(spec.fontFamily)} ${spec.fontWeight} ${spec.fontStyle}`,
        replacement: resolved.font,
      });
  }
  return {
    resolutions,
    missing,
    availableFamilies: [...new Set(available.map((f) => f.family))].sort(),
  };
}

/** Uses only the documented native Plugin API; the same renderer is bundled for
 * the shipped plugin and executed independently in the real-editor check. */
export async function renderScene(
  api: PluginAPI,
  input: unknown,
  options: RenderOptions = {},
): Promise<RenderResult> {
  const pkg = validateScene(input);
  const check = () => {
    if (options.isCancelled?.()) throw new Error('Import cancelled.');
  };
  check();
  const fonts = await preflightFonts(api, pkg, options.fallbackFamily);
  if (fonts.missing.length && options.fontPolicy !== 'substitute')
    throw new Error(
      `Missing exact editor fonts: ${fonts.missing.map((f) => f.requested).join(', ')}. Enable them or explicitly allow substitution.`,
    );
  const uniqueFonts = new Map<string, FontFace>();
  fonts.resolutions.forEach(({ font }) => uniqueFonts.set(`${font.family}|${font.style}`, font));
  await Promise.all([...uniqueFonts.values()].map((font) => api.loadFontAsync(font)));
  check();
  const issues: RenderIssue[] = fonts.missing.map((f) => ({
    code: 'FONT_SUBSTITUTED',
    message: `${f.requested} → ${f.replacement.family} ${f.replacement.style}. Text wrapping may differ.`,
  }));
  const mapping: Record<string, string> = {};
  const screens: string[] = [];
  const stats = {
    text: 0,
    images: 0,
    vectors: 0,
    autoLayout: 0,
    fixedFrames: 0,
    variables: 0,
    textStyles: 0,
    components: 0,
    instances: 0,
  };
  const cleanup: { remove: () => void }[] = [];
  const assets = new Map(pkg.assets.map((a) => [a.id, a]));
  const imageCache = new Map<string, Image>();
  const textStyles = new Map<string, TextStyle>();
  const colors = new Map<string, Variable>();
  const numbers = new Map<number, Variable>();
  let collection: VariableCollection | undefined;
  const prefix = `Import / ${captureHost(pkg.capture.url)} / ${pkg.capture.id.slice(0, 8)}`;
  const staging = api.createFrame();
  cleanup.push(staging);
  staging.name = `${prefix} / Building`;
  staging.fills = [];
  staging.clipsContent = false;
  const right = api.currentPage.children.reduce((max, n) => Math.max(max, n.x + n.width), 0);
  staging.x = right + 120;
  staging.y = 0;
  const paint = (c: RGBA): SolidPaint => {
    let result = solid(c);
    if (options.foundations === false) return result;
    collection ??= api.variables.createVariableCollection(`${prefix} / Foundations`);
    if (!cleanup.includes(collection)) cleanup.push(collection);
    const key = [c.r, c.g, c.b, c.a].map((v) => v.toFixed(5)).join('/');
    let variable = colors.get(key);
    if (!variable) {
      variable = api.variables.createVariable(
        `color/observed-${colors.size + 1}`,
        collection,
        'COLOR',
      );
      variable.scopes = ['FRAME_FILL', 'SHAPE_FILL', 'TEXT_FILL', 'STROKE_COLOR'];
      variable.setValueForMode(collection.defaultModeId, c);
      colors.set(key, variable);
      cleanup.push(variable);
      stats.variables++;
    }
    result = api.variables.setBoundVariableForPaint(result, 'color', variable);
    return result;
  };
  const bindNumber = (
    node: FrameNode,
    field: 'itemSpacing' | 'paddingTop' | 'paddingRight' | 'paddingBottom' | 'paddingLeft',
    value: number,
  ) => {
    node[field] = value;
    if (options.foundations === false) return;
    collection ??= api.variables.createVariableCollection(`${prefix} / Foundations`);
    if (!cleanup.includes(collection)) cleanup.push(collection);
    let variable = numbers.get(value);
    if (!variable) {
      variable = api.variables.createVariable(
        `space/observed-${String(value).replace('.', '_')}`,
        collection,
        'FLOAT',
      );
      variable.scopes = ['GAP'];
      variable.setValueForMode(collection.defaultModeId, value);
      numbers.set(value, variable);
      cleanup.push(variable);
      stats.variables++;
    }
    node.setBoundVariable(field, variable);
  };
  let done = 0;
  const total = allNodes(pkg).length;
  try {
    let offset = 0;
    for (const screen of pkg.screens) {
      check();
      const native = await buildNative(screen.root, staging, undefined, screen.id);
      native.name = `${pkg.capture.title || 'Page'} / ${screen.viewport.width >= 1000 ? 'Desktop' : screen.viewport.width >= 600 ? 'Tablet' : 'Mobile'} / ${screen.viewport.width}`;
      native.x = offset;
      native.y = 0;
      screens.push(native.id);
      offset += screen.root.bounds.width + 80;
    }
    staging.resize(
      Math.max(1, offset - 80),
      Math.max(...pkg.screens.map((s) => s.root.bounds.height), 1),
    );
    if (options.components !== false) {
      const count = await createComponents(
        api,
        pkg,
        { containerId: staging.id, screenIds: screens, createdNodeIds: [], mapping, issues, stats },
        options.metadata !== false,
      );
      stats.components = count.components;
      stats.instances = count.instances;
    }
    staging.name = `${prefix} / Complete`;
    check();
    const createdNodeIds: string[] = [];
    const collect = (n: BaseNode) => {
      createdNodeIds.push(n.id);
      if ('children' in n) (n as ChildrenMixin).children.forEach(collect);
    };
    collect(staging);
    api.currentPage.selection = screens.map((id) => staging.children.find((n) => n.id === id)!);
    api.viewport.scrollAndZoomIntoView([staging]);
    return { containerId: staging.id, screenIds: screens, createdNodeIds, mapping, issues, stats };
  } catch (error) {
    for (const resource of cleanup.reverse())
      try {
        resource.remove();
      } catch {
        /* best-effort cleanup only of resources created here */
      }
    throw error;
  }

  async function buildNative(
    source: SceneNode,
    parent: FrameNode,
    parentSource: SceneNode | undefined,
    screenId: string,
  ): Promise<NativeNode> {
    check();
    let native: NativeNode;
    if (source.kind === 'text') {
      const text = source.text!;
      const node = api.createText();
      native = node;
      parent.appendChild(node);
      node.fontName = fonts.resolutions.get(fontKey(text))!.font;
      node.fontSize = text.fontSize;
      node.lineHeight = { unit: 'PIXELS', value: Math.max(1, text.lineHeight) };
      node.letterSpacing = { unit: 'PIXELS', value: text.letterSpacing };
      node.characters = text.characters;
      node.textAlignHorizontal = text.align.toUpperCase() as TextNode['textAlignHorizontal'];
      node.fills = [paint(text.color)];
      const styleKey = JSON.stringify({ ...text, characters: undefined, runs: undefined });
      if (options.foundations !== false) {
        let style = textStyles.get(styleKey);
        if (!style) {
          style = api.createTextStyle();
          style.name = `${prefix} / Type / ${text.fontSize}-${text.fontWeight}-${textStyles.size + 1}`;
          style.fontName = node.fontName as FontName;
          style.fontSize = text.fontSize;
          style.lineHeight = node.lineHeight;
          style.letterSpacing = node.letterSpacing;
          textStyles.set(styleKey, style);
          cleanup.push(style);
          stats.textStyles++;
        }
        await node.setTextStyleIdAsync(style.id);
      }
      for (const run of text.runs ?? []) {
        if (run.end <= run.start) continue;
        const request = { ...text, ...run };
        node.setRangeFontName(run.start, run.end, fonts.resolutions.get(fontKey(request))!.font);
        if (run.fontSize !== undefined) node.setRangeFontSize(run.start, run.end, run.fontSize);
        if (run.color) node.setRangeFills(run.start, run.end, [paint(run.color)]);
      }
      node.textAutoResize = 'HEIGHT';
      node.resize(Math.max(0.01, source.bounds.width), Math.max(0.01, source.bounds.height));
      stats.text++;
    } else if (source.kind === 'svg') {
      const asset = assets.get(source.assetId!)!;
      const bytes = decodeBase64(asset.data);
      const svg = decodeURIComponent(
        Array.from(bytes, (b) => '%' + b.toString(16).padStart(2, '0')).join(''),
      );
      if (
        /<(script|foreignObject)\b|\bon\w+\s*=|(?:href|src)\s*=\s*["']\s*(?:https?:|javascript:|\/\/)/i.test(
          svg,
        )
      )
        throw new Error('Unsafe SVG asset rejected.');
      native = api.createNodeFromSvg(svg);
      parent.appendChild(native);
      native.resize(Math.max(0.01, source.bounds.width), Math.max(0.01, source.bounds.height));
      stats.vectors++;
    } else if (source.kind === 'image') {
      const asset = assets.get(source.assetId!)!;
      let image = imageCache.get(asset.id);
      if (!image) {
        image = api.createImage(decodeBase64(asset.data));
        imageCache.set(asset.id, image);
      }
      const node = api.createRectangle();
      native = node;
      parent.appendChild(node);
      node.fills = [
        source.image?.fit === 'fill'
          ? {
              type: 'IMAGE',
              imageHash: image.hash,
              scaleMode: 'CROP',
              imageTransform: [
                [1, 0, 0],
                [0, 1, 0],
              ],
            }
          : {
              type: 'IMAGE',
              imageHash: image.hash,
              scaleMode: source.image?.fit === 'contain' ? 'FIT' : 'FILL',
            },
      ];
      node.resize(Math.max(0.01, source.bounds.width), Math.max(0.01, source.bounds.height));
      if (source.image?.position.some((p) => Math.abs(p - 0.5) > 0.001))
        issues.push({
          code: 'IMAGE_POSITION_APPROXIMATED',
          message: 'Non-centered image position needs crop verification.',
          sourceId: source.id,
          nodeId: node.id,
        });
      stats.images++;
    } else {
      const node = api.createFrame();
      native = node;
      parent.appendChild(node);
      node.fills = [];
      node.clipsContent = source.style.clipContent ?? false;
      node.resize(Math.max(0.01, source.bounds.width), Math.max(0.01, source.bounds.height));
      const layout = deriveLayout(source);
      if (layout.mode !== 'none') {
        node.layoutMode =
          layout.mode === 'grid'
            ? 'GRID'
            : (layout.mode.toUpperCase() as 'HORIZONTAL' | 'VERTICAL');
        node.primaryAxisSizingMode = 'FIXED';
        node.counterAxisSizingMode = 'FIXED';
        if (layout.mode === 'grid') {
          const columns = Math.min(layout.columns ?? 1, Math.max(1, source.children.length));
          node.gridColumnCount = columns;
          node.gridRowCount = Math.max(1, Math.ceil(source.children.length / columns));
          node.gridItemsPositioning = 'ROW_AUTO_FLOW';
          node.gridColumnGap = layout.gap;
          node.gridRowGap = layout.rowGap ?? layout.gap;
          for (let i = 0; i < columns; i++) {
            const item = source.children[i];
            if (item) {
              node.gridColumnSizes[i]!.type = 'FLEX';
              node.gridColumnSizes[i]!.value = Math.max(1, item.bounds.width);
            }
          }
          for (const track of node.gridRowSizes) track.type = 'HUG';
        } else {
          bindNumber(node, 'itemSpacing', layout.gap);
          node.layoutWrap = layout.wrap ? 'WRAP' : 'NO_WRAP';
          node.primaryAxisAlignItems =
            layout.justify === 'space-between'
              ? 'SPACE_BETWEEN'
              : layout.justify === 'center'
                ? 'CENTER'
                : layout.justify === 'end'
                  ? 'MAX'
                  : 'MIN';
          node.counterAxisAlignItems =
            layout.align === 'center' ? 'CENTER' : layout.align === 'end' ? 'MAX' : 'MIN';
        }
        const fields = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft'] as const;
        fields.forEach((field, i) => bindNumber(node, field, layout.padding[i]!));
        stats.autoLayout++;
      } else {
        stats.fixedFrames++;
        if (source.layout && source.layout.mode !== 'none')
          issues.push({
            code: 'LAYOUT_FIXED',
            message: 'Overlapping source layout preserved with fixed positions.',
            sourceId: source.id,
            nodeId: node.id,
          });
      }
      const flowChildren = source.children.filter((c) => c.position !== 'absolute');
      let previous: SceneNode | undefined;
      for (const child of source.children) {
        if (
          previous &&
          child.position !== 'absolute' &&
          layout.mode !== 'none' &&
          layout.mode !== 'grid' &&
          !layout.wrap &&
          layout.justify !== 'space-between'
        ) {
          const vertical = layout.mode === 'vertical';
          const measured = vertical
            ? child.bounds.y - previous.bounds.y - previous.bounds.height
            : child.bounds.x - previous.bounds.x - previous.bounds.width;
          const extra = measured - layout.gap;
          if (extra > 1) {
            const spacer = api.createFrame();
            node.appendChild(spacer);
            spacer.name = 'Spacing / source margin';
            spacer.fills = [];
            spacer.resize(vertical ? 0.01 : extra, vertical ? extra : 0.01);
          }
        }
        await buildNative(child, node, source, screenId);
        if (child.position !== 'absolute') previous = child;
      }
      if (layout.mode !== 'none') {
        const border = source.style.border?.width ?? 0;
        // Browser margins before/after the flow are measured, not snapped to a scale.
        const first = flowChildren[0],
          last = flowChildren.at(-1);
        if (first && last && layout.mode === 'vertical' && !layout.wrap) {
          bindNumber(node, 'paddingTop', Math.max(0, first.bounds.y - source.bounds.y - border));
          bindNumber(
            node,
            'paddingBottom',
            Math.max(
              0,
              source.bounds.y + source.bounds.height - last.bounds.y - last.bounds.height - border,
            ),
          );
        }
        if (source.layout?.heightSizing === 'hug') node.layoutSizingVertical = 'HUG';
      }
    }
    native.name = source.name;
    native.opacity = source.style.opacity;
    if ('fills' in native && source.kind === 'frame' && source.style.background)
      native.fills = [paint(source.style.background)];
    if ('strokes' in native && source.style.border && source.style.border.width > 0) {
      native.strokes = [paint(source.style.border.color)];
      native.strokeWeight = source.style.border.width;
      native.strokeAlign = 'INSIDE';
    }
    if ('topLeftRadius' in native && source.style.radius) {
      [
        native.topLeftRadius,
        native.topRightRadius,
        native.bottomRightRadius,
        native.bottomLeftRadius,
      ] = source.style.radius;
    }
    if ('effects' in native && source.style.shadow)
      native.effects = source.style.shadow.map((sh) => ({
        type: 'DROP_SHADOW',
        color: sh.color,
        offset: { x: sh.x, y: sh.y },
        radius: sh.blur,
        spread: sh.spread,
        visible: true,
        blendMode: 'NORMAL',
      }));
    if (parentSource) {
      const mode = deriveLayout(parentSource).mode;
      if (mode === 'none' || source.position === 'absolute') {
        if (parent.layoutMode !== 'NONE') native.layoutPositioning = 'ABSOLUTE';
        native.x = source.bounds.x - parentSource.bounds.x;
        native.y = source.bounds.y - parentSource.bounds.y;
      } else if (mode === 'grid') {
        native.gridChildHorizontalAlign = 'AUTO';
        native.gridChildVerticalAlign = 'MIN';
        native.layoutSizingHorizontal = 'FILL';
      } else {
        const padding = parentSource.layout?.padding ?? [0, 0, 0, 0];
        const inner = parentSource.bounds.width - padding[1] - padding[3];
        if (Math.abs(source.bounds.width - inner) <= 3 || source.layout?.widthSizing === 'fill')
          native.layoutSizingHorizontal = 'FILL';
      }
    }
    // Resizing and parent sizing setters can reset text resizing. Apply it last
    // so edited copy grows vertically instead of clipping at capture-time height.
    if (native.type === 'TEXT')
      native.textAutoResize = source.text?.sizing === 'inline' ? 'WIDTH_AND_HEIGHT' : 'HEIGHT';
    if (options.metadata !== false)
      native.setPluginData(
        'website-source',
        JSON.stringify({
          captureId: pkg.capture.id,
          screenId,
          sourceId: source.id,
          key: source.source.key ?? null,
          bounds: source.bounds,
        }),
      );
    mapping[`${screenId}:${source.id}`] = native.id;
    options.onProgress?.(++done, total);
    return native;
  }
}
