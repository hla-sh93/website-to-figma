import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resolveFont, deriveLayout, decodeBase64, captureHost } from '../src/plugin/renderer.js';
import type { SceneNode, TextSpec } from '../src/core/scene.js';
const text: TextSpec = {
  characters: 'Hello',
  fontFamily: '"Arial", sans-serif',
  fontStyle: 'Regular',
  fontWeight: 700,
  fontSize: 16,
  lineHeight: 24,
  letterSpacing: 0,
  color: { r: 0, g: 0, b: 0, a: 1 },
  align: 'left',
  direction: 'ltr',
};
test('names imports without depending on browser-only URL globals in Figma main', () => {
  assert.equal(captureHost('https://example.com/a'), 'example.com');
  assert.equal(captureHost('fixture:owned'), 'Owned fixture');
});
test('resolves CSS font weight against actual available Figma font faces', () => {
  const result = resolveFont(text, [
    { family: 'Arial', style: 'Regular' },
    { family: 'Arial', style: 'Bold' },
  ]);
  assert.deepEqual(result, { font: { family: 'Arial', style: 'Bold' }, exact: true });
});
test('reports substitution instead of silently treating fallback as exact', () => {
  const result = resolveFont({ ...text, fontFamily: 'Unavailable', fontWeight: 400 }, [
    { family: 'Inter', style: 'Regular' },
  ]);
  assert.equal(result.exact, false);
  assert.equal(result.font.family, 'Inter');
});
test('font resolution fails when no usable font exists', () =>
  assert.throws(() => resolveFont(text, []), /font/i));
test('base64 asset decoding preserves original bytes', () => {
  assert.deepEqual(Array.from(decodeBase64('AAECA/8=')), [0, 1, 2, 3, 255]);
  assert.throws(() => decodeBase64('not base64!'));
});
const frame: SceneNode = {
  id: 'root',
  kind: 'frame',
  name: 'Section',
  source: { tag: 'section' },
  bounds: { x: 0, y: 0, width: 300, height: 160 },
  style: { opacity: 1 },
  layout: {
    mode: 'vertical',
    gap: 0,
    padding: [10, 10, 10, 10],
    align: 'start',
    justify: 'start',
    wrap: false,
    widthSizing: 'fill',
    heightSizing: 'hug',
  },
  children: [
    {
      id: 'a',
      kind: 'frame',
      name: 'A',
      source: { tag: 'div' },
      bounds: { x: 10, y: 10, width: 280, height: 40 },
      style: { opacity: 1 },
      children: [],
    },
    {
      id: 'b',
      kind: 'frame',
      name: 'B',
      source: { tag: 'div' },
      bounds: { x: 10, y: 70, width: 280, height: 80 },
      style: { opacity: 1 },
      children: [],
    },
  ],
};
test('derives measured gaps instead of dropping CSS margin space', () => {
  const layout = deriveLayout(frame);
  assert.equal(layout.mode, 'vertical');
  assert.equal(layout.gap, 20);
});
test('does not force overlapping children into a flow layout', () => {
  const node = structuredClone(frame);
  node.children[1]!.bounds.y = 30;
  assert.equal(deriveLayout(node).mode, 'none');
});
