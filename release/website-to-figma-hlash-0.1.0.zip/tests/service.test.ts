import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createLocalService } from '../src/service/app.js';
import type { ScenePackage } from '../src/core/scene.js';
const scene: ScenePackage = {
  version: 1,
  capture: {
    id: 'x',
    url: 'https://example.com',
    title: 'Test',
    capturedAt: '2026-10-29',
    engine: 'test',
  },
  screens: [
    {
      id: 'desktop',
      viewport: { width: 1440, height: 900, dpr: 1 },
      root: {
        id: 'root',
        kind: 'frame',
        name: 'Page',
        source: { tag: 'body' },
        bounds: { x: 0, y: 0, width: 1440, height: 100 },
        style: { opacity: 1 },
        children: [],
      },
    },
  ],
  assets: [],
  issues: [],
};
test('local API authenticates, rejects foreign origins and validates input before work', async () => {
  const app = await createLocalService({ port: 0, runner: async () => scene });
  try {
    assert.equal((await fetch(app.url + '/health')).status, 401);
    assert.equal(
      (
        await fetch(app.url + '/health', {
          headers: { Authorization: `Bearer ${app.token}`, Origin: 'https://evil.example' },
        })
      ).status,
      403,
    );
    assert.equal((await fetch(app.url + '/', { headers: { Origin: 'null' } })).status, 403);
    const r = await fetch(app.url + '/jobs', {
      method: 'POST',
      headers: { Authorization: `Bearer ${app.token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: 'http://127.0.0.1' }),
    });
    assert.equal(r.status, 400);
    const page = await (await fetch(app.url)).text();
    assert.match(page, /Hla.Sh/);
    assert.doesNotMatch(page, /ai agent/i);
  } finally {
    await app.close();
  }
});
test('job retry is idempotent, returns validated scene, and detects key conflicts', async () => {
  let runs = 0;
  const app = await createLocalService({
    port: 0,
    runner: async () => {
      runs++;
      return structuredClone(scene);
    },
  });
  const headers = {
    Authorization: `Bearer ${app.token}`,
    'Content-Type': 'application/json',
    'Idempotency-Key': 'same-key',
  };
  try {
    const create = () =>
      fetch(app.url + '/jobs', {
        method: 'POST',
        headers,
        body: JSON.stringify({ url: 'https://example.com', widths: [1440] }),
      });
    const first = (await (await create()).json()) as { id: string };
    const second = (await (await create()).json()) as { id: string };
    assert.equal(first.id, second.id);
    for (let i = 0; i < 20; i++) {
      const status = (await (await fetch(app.url + '/jobs/' + first.id, { headers })).json()) as {
        state: string;
      };
      if (status.state === 'ready') break;
      await new Promise((r) => setTimeout(r, 10));
    }
    const result = await fetch(app.url + '/jobs/' + first.id + '/scene', { headers });
    assert.equal(result.status, 200);
    assert.equal(runs, 1);
    assert.equal(
      (
        await fetch(app.url + '/jobs', {
          method: 'POST',
          headers,
          body: JSON.stringify({ url: 'https://example.org' }),
        })
      ).status,
      409,
    );
  } finally {
    await app.close();
  }
});
test('cancellation propagates to a running capture and never publishes its late result', async () => {
  let cancel: () => void = () => {};
  const aborted = new Promise<void>((r) => (cancel = r));
  const app = await createLocalService({
    port: 0,
    runner: async (_request, signal) => {
      await new Promise<void>((resolve) =>
        signal.addEventListener(
          'abort',
          () => {
            cancel();
            resolve();
          },
          { once: true },
        ),
      );
      return scene;
    },
  });
  const headers = { Authorization: `Bearer ${app.token}`, 'Content-Type': 'application/json' };
  try {
    const job = (await (
      await fetch(app.url + '/jobs', {
        method: 'POST',
        headers,
        body: JSON.stringify({ demo: true }),
      })
    ).json()) as { id: string };
    await new Promise((r) => setTimeout(r, 10));
    assert.equal(
      (await fetch(app.url + '/jobs/' + job.id, { method: 'DELETE', headers })).status,
      200,
    );
    await aborted;
    const result = (await (await fetch(app.url + '/jobs/' + job.id, { headers })).json()) as {
      state: string;
    };
    assert.equal(result.state, 'cancelled');
    assert.equal((await fetch(app.url + '/jobs/' + job.id + '/scene', { headers })).status, 409);
  } finally {
    await app.close();
  }
});
