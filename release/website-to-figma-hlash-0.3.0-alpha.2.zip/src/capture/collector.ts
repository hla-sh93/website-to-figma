import type { SceneNode, SceneIssue } from '../core/scene.js';
/** Executed in Chromium. All coordinates remain in the source document space. */
export function collect(selector: string | undefined): {
  root: SceneNode;
  issues: SceneIssue[];
  sources: {
    nodeId: string;
    kind: 'image' | 'svg';
    url: string;
    width: number;
    height: number;
    objectPosition?: string;
  }[];
  textSources: { nodeId: string; selector: string }[];
} {
  const issues: SceneIssue[] = [],
    sources: {
      nodeId: string;
      kind: 'image' | 'svg';
      url: string;
      width: number;
      height: number;
      objectPosition?: string;
    }[] = [];
  const textSources: { nodeId: string; selector: string }[] = [];
  let count = 0;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = colorCanvas.height = 1;
  const colorContext = colorCanvas.getContext('2d', { willReadFrequently: true })!;
  const colorCache = new Map<string, { r: number; g: number; b: number; a: number }>();
  const color = (s: string) => {
    const cached = colorCache.get(s);
    if (cached) return cached;
    colorContext.clearRect(0, 0, 1, 1);
    colorContext.fillStyle = s;
    colorContext.fillRect(0, 0, 1, 1);
    const values = colorContext.getImageData(0, 0, 1, 1).data;
    const value = {
      r: values[0]! / 255,
      g: values[1]! / 255,
      b: values[2]! / 255,
      a: values[3]! / 255,
    };
    colorCache.set(s, value);
    return value;
  };
  const px = (s: string) => parseFloat(s) || 0;
  const cssPath = (el: Element): string => {
    const parts: string[] = [];
    for (let current: Element | null = el; current; current = current.parentElement) {
      const index = current.parentElement
        ? [...current.parentElement.children].indexOf(current) + 1
        : 1;
      parts.unshift(current.tagName.toLowerCase() + `:nth-child(${index})`);
    }
    return parts.join(' > ');
  };
  const variations = (c: CSSStyleDeclaration) => {
    const axes: Record<string, number> = {};
    for (const match of c.fontVariationSettings.matchAll(
      /["']([\x20-\x7e]{4})["']\s+(-?(?:\d*\.)?\d+)/g,
    )) {
      if (Object.keys(axes).length >= 16) break;
      axes[match[1]!] = Number(match[2]);
    }
    return Object.keys(axes).length ? axes : undefined;
  };
  const decoration = (el: Element): 'none' | 'underline' | 'strikethrough' => {
    // Decorations propagate through inline descendants without CSS inheritance.
    let underline = false,
      strike = false;
    for (let current: Element | null = el; current; current = current.parentElement) {
      const line = getComputedStyle(current).textDecorationLine;
      underline ||= line.includes('underline');
      strike ||= line.includes('line-through');
      if (current !== el && !getComputedStyle(current).display.startsWith('inline')) break;
    }
    return underline ? 'underline' : strike ? 'strikethrough' : 'none';
  };
  const lineCache = new Map<string, number>();
  const lineHeight = (c: CSSStyleDeclaration, characters: string) => {
    if (c.lineHeight !== 'normal') return px(c.lineHeight);
    const sample = characters.replace(/[\r\n]/g, ' ').slice(0, 256) || 'Hg';
    const key = [
      c.fontFamily,
      c.fontSize,
      c.fontStyle,
      c.fontWeight,
      c.fontVariationSettings,
      sample,
    ].join('|');
    const known = lineCache.get(key);
    if (known !== undefined) return known;
    const probe = document.createElement('span');
    probe.style.cssText =
      'position:fixed;left:-10000px;top:0;visibility:hidden;display:inline-block;padding:0;border:0;margin:0;white-space:pre;line-height:normal;';
    for (const name of [
      'font-family',
      'font-size',
      'font-style',
      'font-weight',
      'font-stretch',
      'font-variation-settings',
      'font-feature-settings',
    ])
      probe.style.setProperty(name, c.getPropertyValue(name));
    probe.textContent = sample;
    document.documentElement.appendChild(probe);
    const height = probe.getBoundingClientRect().height;
    probe.remove();
    lineCache.set(key, height);
    return height;
  };
  const alignment = (c: CSSStyleDeclaration): 'left' | 'right' | 'center' | 'justify' =>
    c.textAlign === 'center'
      ? 'center'
      : c.textAlign === 'justify'
        ? 'justify'
        : c.textAlign === 'right' ||
            (c.textAlign === 'start' && c.direction === 'rtl') ||
            (c.textAlign === 'end' && c.direction !== 'rtl')
          ? 'right'
          : 'left';
  const issue = (id: string, code: string, message: string) => {
    if (issues.length < 900) issues.push({ code, severity: 'warning', message, nodeId: id });
  };
  const build = (el: Element, path: string, depth: number): SceneNode | null => {
    const c = getComputedStyle(el),
      r = el.getBoundingClientRect();
    if (
      c.display === 'none' ||
      c.visibility === 'hidden' ||
      !r.width ||
      !r.height ||
      r.top + scrollY >= 16000
    )
      return null;
    if (++count > 2200 || depth > 65) throw new Error('Capture DOM node/depth budget exceeded');
    const key = el.getAttribute('data-figma-id') || el.id || path,
      id = path;
    const n: SceneNode = {
      id,
      name: (
        el.getAttribute('aria-label') ||
        el.getAttribute('data-figma-id') ||
        el.id ||
        (
          {
            HEADER: 'Header',
            NAV: 'Navigation',
            MAIN: 'Main',
            SECTION: 'Section',
            ARTICLE: 'Card',
            FOOTER: 'Footer',
            H1: 'Heading',
            H2: 'Heading',
            H3: 'Heading',
            P: 'Description',
            BUTTON: 'Button',
          } as Record<string, string>
        )[el.tagName] ||
        el.classList[0] ||
        el.tagName.toLowerCase()
      )
        .replace(/\s+/g, ' ')
        .slice(0, 100),
      kind: 'frame',
      source: { tag: el.tagName.toLowerCase(), key },
      bounds: { x: r.left + scrollX, y: r.top + scrollY, width: r.width, height: r.height },
      style: {
        opacity: px(c.opacity),
        background: color(c.backgroundColor),
        radius: [
          px(c.borderTopLeftRadius),
          px(c.borderTopRightRadius),
          px(c.borderBottomRightRadius),
          px(c.borderBottomLeftRadius),
        ],
        clipContent: ['hidden', 'clip'].includes(c.overflow),
      },
      children: [],
      position: c.position === 'absolute' || c.position === 'fixed' ? 'absolute' : 'flow',
    };
    if (px(c.borderTopWidth))
      n.style.border = { width: px(c.borderTopWidth), color: color(c.borderTopColor) };
    if (c.transform !== 'none')
      issue(
        id,
        'transform',
        'Transform is retained as measured bounds; editable transform and rotated child geometry are approximated.',
      );
    if (c.boxShadow !== 'none') {
      const m = c.boxShadow.match(
        /^(rgba?\([^)]+\)) (-?[\d.]+)px (-?[\d.]+)px ([\d.]+)px (-?[\d.]+)px$/,
      );
      if (m)
        n.style.shadow = [
          { color: color(m[1]!), x: px(m[2]!), y: px(m[3]!), blur: px(m[4]!), spread: px(m[5]!) },
        ];
      else
        issue(
          id,
          'unsupported-effect',
          'Complex or inset shadow is not represented by editable style.',
        );
    }
    if (c.backgroundImage !== 'none' || c.filter !== 'none')
      issue(
        id,
        'unsupported-effect',
        'Background image/gradient, shadow, or filter is not represented by editable style.',
      );
    for (const pseudo of ['::before', '::after']) {
      const s = getComputedStyle(el, pseudo);
      if (s.content !== 'none' && s.content !== 'normal')
        issue(
          id,
          'pseudo-content',
          'Generated pseudo content is visible in screenshot but not editable.',
        );
    }
    if (['CANVAS', 'VIDEO', 'IFRAME'].includes(el.tagName))
      issue(id, 'unsupported-media', 'Dynamic media is present only in the source screenshot.');
    if (el instanceof HTMLImageElement) {
      n.kind = 'image';
      sources.push({
        nodeId: id,
        kind: 'image',
        url: el.currentSrc || el.src,
        width: el.naturalWidth,
        height: el.naturalHeight,
        objectPosition: c.objectPosition,
      });
      n.image = {
        fit: ['cover', 'contain', 'none', 'scale-down'].includes(c.objectFit)
          ? (c.objectFit as 'cover' | 'contain' | 'none' | 'scale-down')
          : 'fill',
        position: [0.5, 0.5],
        contentBox: {
          x: px(c.borderLeftWidth) + px(c.paddingLeft),
          y: px(c.borderTopWidth) + px(c.paddingTop),
          width: Math.max(
            0,
            r.width -
              px(c.borderLeftWidth) -
              px(c.borderRightWidth) -
              px(c.paddingLeft) -
              px(c.paddingRight),
          ),
          height: Math.max(
            0,
            r.height -
              px(c.borderTopWidth) -
              px(c.borderBottomWidth) -
              px(c.paddingTop) -
              px(c.paddingBottom),
          ),
        },
        ...(el.naturalWidth && el.naturalHeight
          ? { intrinsicSize: { width: el.naturalWidth, height: el.naturalHeight } }
          : {}),
      };
      return n;
    }
    if (el instanceof SVGSVGElement) {
      const clone = el.cloneNode(true) as Element;
      clone
        .querySelectorAll('script,foreignObject,style,animate,set,animateTransform')
        .forEach((e) => e.remove());
      for (const e of [clone, ...clone.querySelectorAll('*')])
        for (const a of [...e.attributes])
          if (
            a.name.startsWith('on') ||
            (/href/i.test(a.name) && !a.value.startsWith('#')) ||
            /url\((?!["']?#)/i.test(a.value)
          )
            e.removeAttribute(a.name);
      n.kind = 'svg';
      sources.push({
        nodeId: id,
        kind: 'svg',
        url: 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(clone.outerHTML))),
        width: r.width,
        height: r.height,
      });
      return n;
    }
    const hasAsset = !!el.querySelector('svg,img,canvas,video,iframe');
    const hasBlock = [...el.children].some(
      (e) =>
        !['inline', 'inline-block', 'contents'].includes(getComputedStyle(e).display) &&
        e.tagName !== 'BR',
    );
    if (!hasBlock && !hasAsset && (el.textContent ?? '').trim()) {
      n.kind = 'text';
      let characters = '';
      const runs: NonNullable<NonNullable<SceneNode['text']>['runs']> = [];
      const add = (node: Node) => {
        if (node instanceof Element) {
          if (getComputedStyle(node).display === 'none') return;
          if (node.tagName === 'BR') {
            characters += '\n';
            return;
          }
          node.childNodes.forEach(add);
          return;
        }
        if (node.nodeType !== Node.TEXT_NODE) return;
        const style = getComputedStyle(node.parentElement!);
        let s = node.textContent ?? '';
        if (!style.whiteSpace.startsWith('pre')) s = s.replace(/\s+/g, ' ');
        if (!characters || characters.endsWith(' ') || characters.endsWith('\n'))
          s = s.replace(/^ +/, '');
        if (style.textTransform === 'uppercase') s = s.toUpperCase();
        if (style.textTransform === 'lowercase') s = s.toLowerCase();
        if (style.textTransform === 'capitalize')
          s = s.replace(/\b\p{L}/gu, (x) => x.toUpperCase());
        const start = characters.length;
        characters += s;
        if (s)
          runs.push({
            start,
            end: characters.length,
            fontFamily: style.fontFamily,
            fontStyle: style.fontStyle,
            fontWeight: px(style.fontWeight) || 400,
            fontSize: px(style.fontSize),
            color: color(style.color),
            textDecoration: decoration(node.parentElement!),
            letterSpacing: px(style.letterSpacing),
            lineHeight: lineHeight(style, s),
            ...(variations(style) ? { variationSettings: variations(style) } : {}),
          });
      };
      el.childNodes.forEach(add);
      characters = characters.trimEnd();
      runs.forEach((t) => (t.end = Math.min(t.end, characters.length)));
      n.text = {
        characters,
        fontFamily: c.fontFamily,
        fontStyle: c.fontStyle,
        fontWeight: px(c.fontWeight) || 400,
        fontSize: px(c.fontSize),
        lineHeight: lineHeight(c, characters),
        textDecoration: decoration(el),
        ...(variations(c) ? { variationSettings: variations(c) } : {}),
        letterSpacing: px(c.letterSpacing),
        color: color(c.color),
        align: alignment(c),
        direction: c.direction === 'rtl' ? 'rtl' : 'ltr',
        sizing: c.display === 'inline' ? 'inline' : 'block',
        runs: runs.filter((t) => t.end > t.start),
      };
      const decorated =
        (n.style.background?.a ?? 0) > 0 ||
        !!n.style.border ||
        !!n.style.shadow ||
        [c.paddingTop, c.paddingRight, c.paddingBottom, c.paddingLeft].some((v) => px(v) > 0);
      if (decorated) {
        const child: SceneNode = {
          ...n,
          id: id + '/text',
          name: n.name + ' text',
          source: { tag: '#text' },
          style: { opacity: 1 },
          children: [],
          bounds: {
            x: n.bounds.x + px(c.borderLeftWidth) + px(c.paddingLeft),
            y: n.bounds.y + px(c.borderTopWidth) + px(c.paddingTop),
            width: Math.max(
              0,
              r.width -
                px(c.borderLeftWidth) -
                px(c.borderRightWidth) -
                px(c.paddingLeft) -
                px(c.paddingRight),
            ),
            height: Math.max(
              0,
              r.height -
                px(c.borderTopWidth) -
                px(c.borderBottomWidth) -
                px(c.paddingTop) -
                px(c.paddingBottom),
            ),
          },
        };
        delete n.text;
        n.kind = 'frame';
        n.children = [child];
        textSources.push({ nodeId: child.id, selector: cssPath(el) });
      } else {
        textSources.push({ nodeId: n.id, selector: cssPath(el) });
        return n;
      }
    }
    if (!n.children.length)
      n.children = [...el.children]
        .map((e, i) => build(e, path + '/' + i, depth + 1))
        .filter((v): v is SceneNode => !!v);
    // Text nodes between block/asset children need their own measured editable nodes.
    if (hasBlock || hasAsset) {
      let index = 0;
      for (const node of el.childNodes) {
        const i = index++;
        if (node.nodeType !== Node.TEXT_NODE || !node.textContent?.trim()) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const b = range.getBoundingClientRect();
        if (!b.width || !b.height) continue;
        const characters = node.textContent.replace(/\s+/g, ' ').trim();
        n.children.push({
          id: id + '/direct-' + i,
          name: 'text',
          kind: 'text',
          source: { tag: '#text' },
          bounds: { x: b.x + scrollX, y: b.y + scrollY, width: b.width, height: b.height },
          style: { opacity: 1 },
          children: [],
          position: 'flow',
          text: {
            characters,
            fontFamily: c.fontFamily,
            fontStyle: c.fontStyle,
            fontWeight: px(c.fontWeight) || 400,
            fontSize: px(c.fontSize),
            lineHeight: lineHeight(c, characters),
            textDecoration: decoration(el),
            ...(variations(c) ? { variationSettings: variations(c) } : {}),
            letterSpacing: px(c.letterSpacing),
            color: color(c.color),
            align: alignment(c),
            direction: c.direction === 'rtl' ? 'rtl' : 'ltr',
            sizing: 'inline',
          },
        });
        textSources.push({ nodeId: id + '/direct-' + i, selector: cssPath(el) });
      }
      n.children.sort((a, b) => {
        const ai = a.id.includes('/direct-')
          ? Number(a.id.split('/direct-')[1])
          : [...el.childNodes].indexOf(el.children[Number(a.id.split('/').at(-1))]!);
        const bi = b.id.includes('/direct-')
          ? Number(b.id.split('/direct-')[1])
          : [...el.childNodes].indexOf(el.children[Number(b.id.split('/').at(-1))]!);
        return ai - bi;
      });
    }
    const flex = c.display.includes('flex'),
      grid = c.display.includes('grid'),
      horizontal = flex && c.flexDirection.startsWith('row');
    const align =
      c.alignItems === 'center'
        ? 'center'
        : c.alignItems.includes('end')
          ? 'end'
          : c.alignItems === 'stretch'
            ? 'stretch'
            : 'start';
    let gap = px(c.gap);
    if (!flex && !grid && n.children.length > 1) {
      const gaps = n.children
        .slice(1)
        .map((x, i) => x.bounds.y - (n.children[i]!.bounds.y + n.children[i]!.bounds.height));
      if (gaps.every((g) => g >= 0) && Math.max(...gaps) - Math.min(...gaps) < 1) gap = gaps[0]!;
      else
        issue(
          id,
          'margin-spacing',
          'Block margin/collapse spacing retained in source coordinates; auto layout is approximate.',
        );
    }
    n.layout = {
      mode: grid ? 'grid' : horizontal ? 'horizontal' : 'vertical',
      gap,
      rowGap: px(c.rowGap),
      padding: [px(c.paddingTop), px(c.paddingRight), px(c.paddingBottom), px(c.paddingLeft)],
      align,
      justify:
        c.justifyContent === 'space-between'
          ? 'space-between'
          : c.justifyContent === 'center'
            ? 'center'
            : c.justifyContent.includes('end')
              ? 'end'
              : 'start',
      wrap: c.flexWrap === 'wrap',
      widthSizing:
        el.parentElement &&
        Math.abs(
          r.width -
            (el.parentElement.getBoundingClientRect().width -
              px(getComputedStyle(el.parentElement).paddingLeft) -
              px(getComputedStyle(el.parentElement).paddingRight) -
              px(getComputedStyle(el.parentElement).borderLeftWidth) -
              px(getComputedStyle(el.parentElement).borderRightWidth)),
        ) < 1
          ? 'fill'
          : 'fixed',
      heightSizing:
        !(el as HTMLElement).style.height && c.display !== 'inline' && n.children.length > 0
          ? 'hug'
          : 'fixed',
      ...(grid ? { columns: c.gridTemplateColumns.split(' ').filter(Boolean).length } : {}),
      ...(c.minWidth.endsWith('px') ? { minWidth: px(c.minWidth) } : {}),
      ...(c.maxWidth.endsWith('px') ? { maxWidth: px(c.maxWidth) } : {}),
    };
    const widthExtras =
      c.boxSizing === 'border-box'
        ? 0
        : px(c.paddingLeft) + px(c.paddingRight) + px(c.borderLeftWidth) + px(c.borderRightWidth);
    if (n.layout.minWidth !== undefined) n.layout.minWidth += widthExtras;
    if (n.layout.maxWidth !== undefined) {
      n.layout.maxWidth += widthExtras;
      // CSS gives min-width precedence when its bounds conflict with max-width.
      n.layout.maxWidth = Math.max(n.layout.maxWidth, n.layout.minWidth ?? 0);
    }
    const unsupportedGrid =
      grid &&
      (c.gridAutoFlow !== 'row' ||
        /\[|subgrid|masonry/.test(c.gridTemplateColumns) ||
        [...el.children].some((child) => {
          const style = getComputedStyle(child);
          return [
            style.gridColumnStart,
            style.gridColumnEnd,
            style.gridRowStart,
            style.gridRowEnd,
          ].some((value) => value !== 'auto');
        }));
    const reversed =
      flex &&
      (c.flexDirection.endsWith('reverse') ||
        c.flexWrap === 'wrap-reverse' ||
        [...el.children].some((child) => getComputedStyle(child).order !== '0'));
    if (unsupportedGrid || reversed) {
      n.layout.mode = 'none';
      issue(
        id,
        'layout-fixed-unsupported',
        'Grid placement, spans, dense flow, reversed flow or reordered children retained as measured fixed positions.',
      );
    }
    return n;
  };
  const el = selector ? document.querySelector(selector) : document.body;
  if (!el) throw new Error('Capture selector was not found');
  const root = build(el, 'root', 0);
  if (!root) throw new Error('Capture selector is not visible');
  return { root, issues, sources, textSources };
}
