/** Called from the Figma main sandbox; never from the untrusted iframe. */
export async function connectLocalService(
  request: typeof fetch = fetch,
  base = 'http://localhost:4017',
  pairingKey = '__HLA_LOCAL_PAIRING_KEY__',
) {
  const response = await request(base + '/plugin-session', {
    method: 'GET',
    headers: { 'X-Plugin-Pairing': pairingKey },
  });
  if (!response.ok)
    throw new Error('الخدمة المحلية غير جاهزة. شغّلي خدمة الالتقاط ثم حاولي مجدداً.');
  const data = (await response.json()) as { token?: unknown };
  if (typeof data.token !== 'string' || !/^[a-f0-9]{48}$/.test(data.token))
    throw new Error('تعذر الاتصال بخدمة الالتقاط.');
  return data.token;
}
