import { validateScene, type ScenePackage } from '../core/scene.js';
import { createRequestKey } from './request-key.js';
import type { RenderResult } from './renderer.js';
const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
const select = (id: string) => $<HTMLSelectElement>(id);
const send = (type: string, data: object = {}) =>
  parent.postMessage({ pluginMessage: { type, ...data } }, '*');
let token = '',
  busy = false,
  phase = 'idle',
  generation = 0,
  jobId: string | undefined,
  scene: ScenePackage | undefined,
  substituted = false;
let touched = false,
  pasteTimer: ReturnType<typeof setTimeout> | undefined;
let connection: Promise<boolean> | undefined,
  connectionResolve: ((connected: boolean) => void) | undefined,
  connectionTimer: ReturnType<typeof setTimeout> | undefined;
const status = (text: string, error = false) => {
  $('status').textContent = text;
  $('status').className = error ? 'error' : '';
};
function setBusy(value: boolean) {
  busy = value;
  $<HTMLFieldSetElement>('settings').disabled = value;
  $<HTMLButtonElement>('submit').disabled = value;
  $('progress').hidden = !value;
  $('cancel').hidden = !value;
  $('submit').textContent = value ? 'جارٍ النسخ…' : 'نسخ إلى Figma';
  if (!value) phase = 'idle';
}
function finishError(message: string) {
  setBusy(false);
  $('font-note').hidden = true;
  status(message, true);
}
function ensureConnection(): Promise<boolean> {
  if (token) return Promise.resolve(true);
  if (connection) return connection;
  connection = new Promise((resolve) => {
    connectionResolve = resolve;
    connectionTimer = setTimeout(() => {
      resolve(false);
      connection = undefined;
      connectionResolve = undefined;
    }, 8000);
  });
  send('CONNECT');
  return connection;
}
async function api(path: string, options: RequestInit = {}, retry = true): Promise<any> {
  const response = await fetch('http://localhost:4017' + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + token,
      ...options.headers,
    },
  });
  if (response.status === 401 && retry) {
    token = '';
    if (await ensureConnection()) return api(path, options, false);
  }
  const data = await response.json();
  if (!response.ok)
    throw new Error(
      response.status === 404
        ? 'انتهت جلسة الالتقاط. حاولي مجدداً.'
        : String(data.error || 'تعذر إكمال النسخ.'),
    );
  return data;
}
function validUrl() {
  try {
    const url = new URL($<HTMLInputElement>('url').value.trim());
    return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password;
  } catch {
    return false;
  }
}
function savePreferences() {
  send('SAVE_PREFERENCES', {
    preferences: {
      size: select('size').value,
      theme: select('theme').value,
      language: select('language').value,
    },
  });
}
async function capture() {
  if (busy) return;
  clearTimeout(pasteTimer);
  pasteTimer = undefined;
  if (!validUrl()) {
    status('الصقي رابط موقع يبدأ بـ https:// أو http://', true);
    return;
  }
  const requestId = ++generation;
  jobId = undefined;
  scene = undefined;
  substituted = false;
  $('notes').hidden = true;
  $('font-note').hidden = true;
  setBusy(true);
  phase = 'connecting';
  status('جارٍ الاتصال…');
  try {
    if (!(await ensureConnection())) {
      if (requestId === generation)
        finishError('شغّلي خدمة الالتقاط المحلية ثم اضغطي نسخ إلى Figma.');
      return;
    }
    if (requestId !== generation) return;
    savePreferences();
    phase = 'capture';
    status('جارٍ التقاط الموقع…');
    const size = select('size').value,
      language = select('language').value;
    const job = await api('/jobs', {
      method: 'POST',
      headers: { 'Idempotency-Key': createRequestKey() },
      body: JSON.stringify({
        url: $<HTMLInputElement>('url').value.trim(),
        widths: size === 'all' ? [1440, 768, 390] : [Number(size)],
        theme: select('theme').value,
        ...(language === 'original' ? {} : { language }),
      }),
    });
    if (requestId !== generation) {
      void api('/jobs/' + job.id, { method: 'DELETE' }).catch(() => {});
      return;
    }
    jobId = job.id;
    while (requestId === generation) {
      const state = await api('/jobs/' + jobId);
      if (requestId !== generation) return;
      if (state.state === 'ready') {
        const value = await api('/jobs/' + jobId + '/scene');
        if (requestId !== generation) return;
        scene = validateScene(value);
        phase = 'fonts';
        status('جارٍ تجهيز الخطوط…');
        send('PREFLIGHT', { scene, fallback: 'Inter', requestId });
        return;
      }
      if (state.state === 'failed' || state.state === 'cancelled')
        throw new Error(state.error || 'تعذر التقاط الموقع.');
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
  } catch (error) {
    if (requestId === generation)
      finishError(
        error instanceof TypeError
          ? 'تعذر الاتصال بخدمة الالتقاط المحلية.'
          : error instanceof Error
            ? error.message
            : 'تعذر إكمال النسخ.',
      );
  }
}
function insert(allowSubstitution = false) {
  if (!scene || !busy) return;
  substituted = allowSubstitution;
  phase = 'import';
  $('font-note').hidden = true;
  status('جارٍ إنشاء التصميم في Figma…');
  send('IMPORT', {
    scene,
    allowSubstitution,
    foundations: true,
    fallback: 'Inter',
    requestId: generation,
  });
}
function showNotes(result: RenderResult) {
  const messages = new Set<string>();
  for (const issue of [
    ...scene!.issues.filter((issue) => issue.severity === 'warning'),
    ...result.issues,
  ]) {
    const code = issue.code.toLowerCase();
    messages.add(
      /font/.test(code)
        ? 'بعض الخطوط أو تفاصيل النص تحتاج مراجعة.'
        : /image|asset|crop/.test(code)
          ? 'راجعي الصور والقص عند تغيير حجم الإطار.'
          : /layout|spacing|margin/.test(code)
            ? 'بعض ترتيبات الموقع محفوظة كمواضع ثابتة.'
            : /effect|transform|pseudo|media/.test(code)
              ? 'بعض التأثيرات المرئية غير مدعومة بالكامل.'
              : 'توجد تفاصيل في الموقع تحتاج مراجعة بعد النسخ.',
    );
  }
  if (substituted) messages.add('استُخدم خط بديل بموافقتك؛ قد يختلف التفاف النص.');
  $('note-list').replaceChildren();
  for (const message of messages) {
    const li = document.createElement('li');
    li.textContent = message;
    $('note-list').append(li);
  }
  $('notes').hidden = messages.size === 0;
}
$('capture-form').onsubmit = (event) => {
  event.preventDefault();
  void capture();
};
$('submit').onclick = () => void capture();
$('url').onkeydown = (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    void capture();
  }
};
$('url').addEventListener('paste', () => {
  setTimeout(() => {
    if (busy || !validUrl()) return;
    clearTimeout(pasteTimer);
    pasteTimer = setTimeout(() => void capture(), 900);
  }, 0);
});
for (const id of ['size', 'theme', 'language'])
  select(id).onchange = () => {
    touched = true;
    savePreferences();
    if (pasteTimer) {
      clearTimeout(pasteTimer);
      pasteTimer = setTimeout(() => void capture(), 900);
    }
  };
$('allow-fonts').onclick = () => insert(true);
$('cancel').onclick = async () => {
  if (!busy) return;
  if (phase === 'import') {
    phase = 'stopping';
    status('جارٍ إلغاء النسخ…');
    send('CANCEL');
    return;
  }
  generation++;
  const cancelledJob = jobId;
  jobId = undefined;
  setBusy(false);
  $('font-note').hidden = true;
  status('تم الإلغاء.');
  if (cancelledJob)
    try {
      await api('/jobs/' + cancelledJob, { method: 'DELETE' });
    } catch {}
};
window.onmessage = (event: MessageEvent) => {
  if (event.source !== parent) return;
  const data = event.data?.pluginMessage;
  if (!data || typeof data.type !== 'string') return;
  if (data.type === 'PREFERENCES') {
    if (!touched && !busy && data.preferences)
      for (const id of ['size', 'theme', 'language']) {
        const value = String(data.preferences[id]);
        if ([...select(id).options].some((option) => option.value === value))
          select(id).value = value;
      }
    return;
  }
  if (data.type === 'CONNECTED' || data.type === 'CONNECTION_ERROR') {
    clearTimeout(connectionTimer);
    const resolve = connectionResolve;
    connection = undefined;
    connectionResolve = undefined;
    if (
      data.type === 'CONNECTED' &&
      typeof data.token === 'string' &&
      /^[a-f0-9]{48}$/.test(data.token)
    ) {
      token = data.token;
      resolve?.(true);
      if (!busy) status('');
    } else {
      resolve?.(false);
      if (!busy) status('شغّلي خدمة الالتقاط المحلية ثم الصقي رابط الموقع.', true);
    }
    return;
  }
  if (data.requestId !== generation || !busy) return;
  if (data.type === 'ERROR') {
    finishError(String(data.message || 'تعذر إكمال النسخ.'));
    return;
  }
  if (data.type === 'CANCELLED') {
    setBusy(false);
    status('تم الإلغاء.');
    return;
  }
  if (data.type === 'PREFLIGHT_RESULT' && phase === 'fonts') {
    if (data.missing.length) {
      $('font-note').hidden = false;
      $('progress').hidden = true;
      $('font-message').textContent =
        'خط الموقع غير متوفر في Figma. ثبّتيه للحفاظ على النص، أو اختاري المتابعة بخط بديل.';
      status('بانتظار الخط المطلوب.');
    } else insert();
    return;
  }
  if (data.type === 'IMPORT_PROGRESS' && phase === 'import') {
    $<HTMLProgressElement>('progress').max = data.total;
    $<HTMLProgressElement>('progress').value = data.done;
  }
  if (data.type === 'IMPORT_RESULT') {
    showNotes(data.result);
    setBusy(false);
    status(substituted ? 'تم النسخ باستخدام خط بديل.' : 'تم نسخ التصميم إلى Figma.');
  }
};
send('READY');
void ensureConnection();
