import { validateScene, type ScenePackage } from '../core/scene.js';
import { flatten } from '../core/analysis.js';
import { renderScene, preflightFonts, type RenderResult } from './renderer.js';
import { connectLocalService } from './connection.js';
declare const __html__: string;
figma.showUI(__html__, { width: 400, height: 510, themeColors: true });
let current: ScenePackage | undefined,
  result: RenderResult | undefined,
  busy = false,
  cancelled = false;
const post = (type: string, data: unknown = {}) =>
  figma.ui.postMessage({ type, ...(data as object) });
figma.ui.onmessage = async (message: unknown) => {
  if (!message || typeof message !== 'object' || !('type' in message)) return;
  const data = message as Record<string, unknown>;
  try {
    if (data.type === 'READY') {
      const preferences = await figma.clientStorage
        .getAsync('website-preferences')
        .catch(() => undefined);
      post('PREFERENCES', { preferences });
      return;
    }
    if (data.type === 'CONNECT') {
      try {
        const token = await connectLocalService();
        post('CONNECTED', { token });
      } catch {
        post('CONNECTION_ERROR');
      }
      return;
    }
    if (data.type === 'SAVE_PREFERENCES') {
      const p = data.preferences as Record<string, unknown> | undefined;
      if (
        p &&
        ['1440', '768', '390', 'all'].includes(String(p.size)) &&
        ['light', 'dark'].includes(String(p.theme)) &&
        ['original', 'ar', 'en'].includes(String(p.language))
      )
        await figma.clientStorage.setAsync('website-preferences', {
          size: p.size,
          theme: p.theme,
          language: p.language,
        });
      return;
    }
    if (data.type === 'CANCEL') {
      cancelled = true;
      return;
    }
    if (data.type === 'PREFLIGHT') {
      const scene = validateScene(data.scene);
      const fonts = await preflightFonts(
        figma,
        scene,
        typeof data.fallback === 'string' ? data.fallback : undefined,
      );
      post('PREFLIGHT_RESULT', {
        requestId: data.requestId,
        missing: fonts.missing,
        availableFamilies: fonts.availableFamilies,
      });
      return;
    }
    if (data.type === 'IMPORT') {
      if (busy) throw new Error('An import is already running.');
      busy = true;
      cancelled = false;
      try {
        const scene = validateScene(data.scene);
        let last = 0;
        const next = await renderScene(figma, scene, {
          fontPolicy: data.allowSubstitution === true ? 'substitute' : 'stop',
          fallbackFamily: typeof data.fallback === 'string' ? data.fallback : undefined,
          foundations: data.foundations !== false,
          isCancelled: () => cancelled,
          onProgress: (done, total) => {
            if (done - last >= 15 || done === total) {
              post('IMPORT_PROGRESS', { done, total, requestId: data.requestId });
              last = done;
            }
          },
        });
        current = scene;
        result = next;
        post('IMPORT_RESULT', { result, requestId: data.requestId });
      } finally {
        busy = false;
      }
      return;
    }
    if (
      data.type === 'SELECT' &&
      typeof data.nodeId === 'string' &&
      result?.createdNodeIds.includes(data.nodeId)
    ) {
      const node = await figma.getNodeByIdAsync(data.nodeId);
      if (node && 'visible' in node) {
        figma.currentPage.selection = [node];
        figma.viewport.scrollAndZoomIntoView([node]);
      }
      return;
    }
    if (data.type === 'VERIFY') {
      if (busy || !current || !result || typeof data.screenId !== 'string')
        throw new Error('Import a capture before checking it.');
      const index = current.screens.findIndex((s) => s.id === data.screenId);
      if (index < 0) throw new Error('Screen not found.');
      const source = current.screens[index]!;
      const root = await figma.getNodeByIdAsync(result.screenIds[index]!);
      if (!root || !('absoluteTransform' in root)) throw new Error('Imported frame was removed.');
      if (root.width * root.height > 16000000)
        throw new Error(
          'This frame is too large for a full comparison. Capture and verify a selected section.',
        );
      const origin = root.absoluteTransform;
      const geometry = [];
      for (const node of flatten(source.root)) {
        const id = result.mapping[`${source.id}:${node.id}`];
        if (!id) continue;
        const native = await figma.getNodeByIdAsync(id);
        if (!native || !('absoluteTransform' in native)) continue;
        geometry.push({
          sourceId: node.id,
          bounds: {
            x: native.absoluteTransform[0][2] - origin[0][2] + source.root.bounds.x,
            y: native.absoluteTransform[1][2] - origin[1][2] + source.root.bounds.y,
            width: native.width,
            height: native.height,
          },
          ...(native.type === 'TEXT' ? { text: native.characters } : {}),
        });
      }
      const bytes = await root.exportAsync({
        format: 'PNG',
        constraint: { type: 'SCALE', value: 1 },
      });
      post('VERIFY_EXPORT', { screenId: source.id, png: figma.base64Encode(bytes), geometry });
      return;
    }
  } catch (error) {
    post(data.type === 'IMPORT' && cancelled ? 'CANCELLED' : 'ERROR', {
      message: error instanceof Error ? error.message : 'Operation failed.',
      requestId: data.requestId,
    });
  }
};
