import { validateScene, type ScenePackage } from '../core/scene.js';
import { analyzeScene } from '../core/analysis.js';
import type { RenderResult } from './renderer.js';
import { createRequestKey } from './request-key.js';
const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
const input = (id: string) => $<HTMLInputElement>(id);
function preview(id: string, holder: string, src: string, alt: string) {
  let img = document.getElementById(id) as HTMLImageElement | null;
  if (!img) {
    img = document.createElement('img');
    img.id = id;
    img.className = 'preview';
    img.alt = alt;
    img.src = src;
    $(holder).append(img);
  } else img.src = src;
}
const send = (type: string, data: object = {}) =>
  parent.postMessage({ pluginMessage: { type, ...data } }, '*');
let token = '',
  jobId: string | undefined,
  scene: ScenePackage | undefined,
  result: RenderResult | undefined,
  screenIndex = 0,
  busy = false,
  captureInProgress = false,
  captureCancelled = false;
let images: { source: string; rendered?: string; overlay?: string; diff?: string } = { source: '' };
const status = (message: string, error = false) => {
  $('status').textContent = message;
  $('status').className = error ? 'error' : '';
};
const setBusy = (value: boolean) => {
  busy = value;
  $('cancel').hidden = !value;
  $('progress').hidden = !value;
  for (const id of [
    'analyze',
    'demo',
    'import',
    'verify',
    'open-file',
    'offline-file',
    'new-capture',
    'connect-button',
  ])
    $<HTMLButtonElement>(id).disabled = value;
};
async function api(path: string, options: RequestInit = {}) {
  const response = await fetch('http://localhost:4017' + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + token,
      ...options.headers,
    },
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Local service request failed.');
  return data;
}
function report(error: unknown) {
  status(error instanceof Error ? error.message : 'Operation failed.', true);
  setBusy(false);
}
function show(id: string) {
  $('connect').hidden = id !== 'connect';
  $('capture-form').hidden = id !== 'capture-form';
  $('review').hidden = id !== 'review';
}
async function connect() {
  setBusy(true);
  try {
    token = input('token').value.trim();
    if (!/^[a-f0-9]{48}$/.test(token))
      throw new Error('Paste the 48-character session code from the local dashboard.');
    await api('/health');
    show('capture-form');
    status('Connected to local capture service.');
  } catch (e) {
    report(e);
  } finally {
    setBusy(false);
  }
}
function listIssues() {
  const list = $('issues');
  list.replaceChildren();
  if (!scene) return;
  const screen = scene.screens[screenIndex]!;
  const issues = [
    ...scene.issues
      .filter((i) => !i.screenId || i.screenId === screen.id)
      .map((i) => ({
        message: i.message,
        nodeId: i.nodeId ? result?.mapping[`${screen.id}:${i.nodeId}`] : undefined,
      })),
    ...(result?.issues ?? []),
  ];
  for (const issue of issues) {
    const button = document.createElement('button');
    button.className = 'issue';
    button.textContent = issue.message;
    button.onclick = () => {
      if (issue.nodeId) send('SELECT', { nodeId: issue.nodeId });
    };
    list.append(button);
  }
  if (!issues.length) {
    const p = document.createElement('p');
    p.textContent = 'No capture notices.';
    list.append(p);
  }
}
function selectScreen(index: number) {
  screenIndex = index;
  const screen = scene!.screens[index]!;
  images = { source: screen.screenshot ? 'data:image/png;base64,' + screen.screenshot : '' };
  $('source-holder').hidden = !images.source;
  if (images.source) preview('source', 'source-holder', images.source, 'Captured source reference');
  $('comparison').hidden = true;
  for (const [i, button] of [...$('screens').children].entries())
    button.classList.toggle('active', i === index);
  listIssues();
}
function showScene(value: unknown) {
  scene = validateScene(value);
  result = undefined;
  screenIndex = 0;
  show('review');
  $('after-import').hidden = true;
  $('font-notice').hidden = true;
  input('allow-fonts').checked = false;
  const analysis = analyzeScene(scene);
  $('summary').textContent =
    `${analysis.summary.screens} viewports · ${analysis.summary.nodes} layers · ${analysis.summary.assets} assets · ${analysis.components.length} repeated component candidates`;
  $('screens').replaceChildren();
  scene.screens.forEach((screen, index) => {
    const button = document.createElement('button');
    button.textContent = `${screen.viewport.width} px`;
    button.onclick = () => selectScreen(index);
    $('screens').append(button);
  });
  selectScreen(0);
  $('responsive').hidden = analysis.responsive.length === 0;
  $('responsive').textContent =
    `${analysis.responsive.length} observed responsive changes across captured widths. Separate viewport frames preserve structural changes; exact breakpoint thresholds are not inferred from these samples.`;
  send('PREFLIGHT', { scene, fallback: $<HTMLSelectElement>('fallback').value });
  status('Checking editor fonts…');
}
async function capture(demo: boolean) {
  if (busy) return;
  setBusy(true);
  captureInProgress = true;
  captureCancelled = false;
  jobId = undefined;
  try {
    const selector = input('selector').value.trim();
    const widths = input('widths').value.split(',').map(Number);
    const job = await api('/jobs', {
      method: 'POST',
      headers: { 'Idempotency-Key': createRequestKey() },
      body: JSON.stringify({
        ...(demo ? { demo: true } : { url: input('url').value.trim() }),
        widths,
        theme: $<HTMLSelectElement>('theme').value,
        ...(selector ? { selector } : {}),
      }),
    });
    jobId = job.id;
    while (!captureCancelled) {
      const state = await api('/jobs/' + jobId);
      status(state.stage);
      if (state.state === 'ready') {
        showScene(await api('/jobs/' + jobId + '/scene'));
        return;
      }
      if (state.state === 'failed' || state.state === 'cancelled')
        throw new Error(state.error || state.stage);
      await new Promise((r) => setTimeout(r, 500));
    }
  } catch (e) {
    report(e);
  } finally {
    captureInProgress = false;
    setBusy(false);
  }
}
$('connect-button').onclick = () => void connect();
$('analyze').onclick = () => void capture(false);
$('demo').onclick = () => void capture(true);
$('open-file').onclick = () => input('file').click();
$('offline-file').onclick = () => input('file').click();
input('file').onchange = async () => {
  try {
    const file = input('file').files?.[0];
    if (!file) return;
    if (file.size > 40 * 1024 * 1024) throw new Error('Capture package exceeds 40 MiB.');
    jobId = undefined;
    showScene(JSON.parse(await file.text()));
  } catch (e) {
    report(e);
  }
};
$('import').onclick = () => {
  if (busy || !scene) return;
  setBusy(true);
  $('progress').removeAttribute('value');
  status('Creating native Figma layers…');
  send('IMPORT', {
    scene,
    allowSubstitution: input('allow-fonts').checked,
    foundations: input('foundations').checked,
    fallback: $<HTMLSelectElement>('fallback').value,
  });
};
$('fallback').onchange = () => {
  if (scene) send('PREFLIGHT', { scene, fallback: $<HTMLSelectElement>('fallback').value });
};
$('verify').onclick = () => {
  if (!scene || busy) return;
  if (!jobId) {
    status(
      'File imports can be edited, but comparison requires a capture from this service session.',
      true,
    );
    return;
  }
  setBusy(true);
  status('Exporting the Figma frame…');
  send('VERIFY', { screenId: scene.screens[screenIndex]!.id });
};
$('select-frame').onclick = () => {
  if (result) send('SELECT', { nodeId: result.screenIds[screenIndex] });
};
$('cancel').onclick = async () => {
  captureCancelled = true;
  send('CANCEL');
  if (captureInProgress && jobId)
    try {
      await api('/jobs/' + jobId, { method: 'DELETE' });
    } catch {}
  status('Cancellation requested.');
};
$('new-capture').onclick = () => {
  show('capture-form');
  status('');
};
$('disconnect').onclick = () => {
  if (busy) return;
  token = '';
  input('token').value = '';
  show('connect');
  status('Disconnected.');
};
for (const type of ['source', 'rendered', 'overlay', 'diff'] as const)
  $('view-' + type).onclick = () => {
    const image = images[type];
    if (image) $<HTMLImageElement>('comp-image').src = image;
    for (const other of ['source', 'rendered', 'overlay', 'diff'])
      $('view-' + other).classList.toggle('active', other === type);
  };
window.onmessage = async (event: MessageEvent) => {
  if (event.source !== parent) return;
  const data = event.data?.pluginMessage;
  if (!data || typeof data.type !== 'string') return;
  try {
    if (data.type === 'ERROR') {
      report(new Error(data.message));
      return;
    }
    if (data.type === 'PREFLIGHT_RESULT') {
      const select = $<HTMLSelectElement>('fallback'),
        old = select.value;
      select.replaceChildren();
      for (const family of data.availableFamilies) {
        const option = document.createElement('option');
        option.textContent = family;
        select.append(option);
      }
      select.value = data.availableFamilies.includes(old) ? old : 'Inter';
      $('font-notice').hidden = data.missing.length === 0;
      $('font-notice').textContent = data.missing.length
        ? data.missing
            .map(
              (f: { requested: string; replacement: { family: string; style: string } }) =>
                `${f.requested} → ${f.replacement.family} ${f.replacement.style}`,
            )
            .join('\n')
        : '';
      status(
        data.missing.length
          ? 'Review the font substitutions before importing.'
          : 'Fonts are available. Ready to import.',
      );
    }
    if (data.type === 'IMPORT_PROGRESS') {
      $<HTMLProgressElement>('progress').max = data.total;
      $<HTMLProgressElement>('progress').value = data.done;
      status(`Creating layers · ${data.done} of ${data.total}`);
    }
    if (data.type === 'IMPORT_RESULT') {
      result = data.result;
      $('after-import').hidden = false;
      $('stats').replaceChildren();
      for (const [value, label] of [
        [result!.stats.text, 'Editable texts'],
        [result!.stats.autoLayout, 'Auto layouts'],
        [result!.stats.variables, 'Variables'],
      ]) {
        const box = document.createElement('div');
        box.className = 'stat';
        const number = document.createElement('b');
        number.textContent = String(value);
        box.append(number, document.createTextNode(String(label)));
        $('stats').append(box);
      }
      listIssues();
      status('Imported. Resize and edit the frames, then compare with the source.');
      setBusy(false);
    }
    if (data.type === 'VERIFY_EXPORT') {
      const source = scene!.screens.find((s) => s.id === data.screenId)!;
      const comparison = await api('/jobs/' + jobId + '/compare', {
        method: 'POST',
        body: JSON.stringify({ screenId: data.screenId, png: data.png, geometry: data.geometry }),
      });
      images = {
        source: 'data:image/png;base64,' + source.screenshot,
        rendered: 'data:image/png;base64,' + data.png,
        overlay: 'data:image/png;base64,' + comparison.visual.overlay,
        diff: 'data:image/png;base64,' + comparison.visual.diff,
      };
      $('comparison').hidden = false;
      preview('comp-image', 'comp-holder', images.overlay!, 'Visual comparison');
      const g = comparison.geometry;
      $('metrics').textContent =
        `${(comparison.visual.changedFraction * 100).toFixed(1)}% of pixels exceed the comparison threshold${comparison.visual.sizeMismatch ? ' · Frame dimensions differ' : ''}. ${g ? g.withinTolerance + ' of ' + g.total + ' source boxes are within ' + g.tolerance + ' px.' : ''} Pixel difference is a diagnostic, not a universal accuracy score.`;
      status('Comparison complete.');
      setBusy(false);
    }
  } catch (e) {
    report(e);
  }
};
