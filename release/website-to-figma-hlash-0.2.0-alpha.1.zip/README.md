# Website to Figma

**By Hla.Sh · Development build 0.2.0-alpha.1**

Capture a public website at selected widths and import editable text, original images, SVG vectors, native Auto Layout, local text styles, bound color/spacing variables, and conservative repeated component families into Figma Design.

This is the first executable feasibility/alpha build. It includes explicit font substitution review, source previews, a visual difference/overlay report, source-to-layer selection, cancellation, section capture, and offline capture-file import. The broader roadmap is in [tasks/plan.md](tasks/plan.md); actual verification is in [tasks/verification.md](tasks/verification.md).

## Start locally

Requirements: Node.js 24 recommended (22 minimum), npm, Chromium or Google Chrome, and Figma Desktop with permission to run development plugins.

```powershell
npm ci
npx playwright install chromium
npm run build
npm run dev
```

If Google Chrome is already installed at its standard Windows location, the capture service can use it. Set CHROMIUM_EXECUTABLE_PATH to a compatible executable when needed. On Linux CI, use `npx playwright install --with-deps chromium`.

Open **http://localhost:4017**. The local dashboard shows the session code and can capture the owned demo or a public URL. Keep the service running while using URL capture or comparison. Captures are held in memory for up to 30 minutes and cleared when the service stops; at most six are retained per session. The plugin uses localhost because Figma rejects the numeric loopback URL in devAllowedDomains. The service remains bound to IPv4 loopback and also accepts its exact 127.0.0.1 authority.

## Load the development plugin

1. In Figma Desktop, create a new local development plugin to obtain your Figma-assigned plugin ID. The repository manifest contains a development placeholder, not a published plugin identity.
2. Set the assigned ID and rebuild:

   ```powershell
   npm run configure-plugin -- --id YOUR_FIGMA_PLUGIN_ID
   npm run build
   ```

3. Import the plugin from **dist/manifest.json** through Figma's development plugin menu.
4. Run **Website to Figma · Hla.Sh**. Paste the session code from the local dashboard and connect.
5. Paste a public URL or choose **Try owned demo**. Review missing fonts, explicitly allow substitutions if appropriate, and choose **Create editable design**.
6. Use **Compare with source** to inspect the source, Figma export, overlay, and difference. Issue entries select mapped layers when available.

Figma assigns plugin IDs through its creation/publishing workflow. See the [official manifest documentation](https://developers.figma.com/docs/plugins/manifest/). This project has not been published to the Community.

An existing capture package can also be opened from the connection screen without starting the service. Source/Figma comparison requires a job retained in the current service session.

## Commands

```powershell
npm run check
npm run capture -- --url https://example.com --out output/example.json --widths 1440,390
npm run capture -- --fixture fixtures/reference.html --selector '#features' --out output/features.json
npm run benchmark
npm run benchmark -- --source source.png --rendered figma.png --out output/comparison
```

`npm run check` checks formatting, TypeScript, unit/API integration tests, a clean plugin build, and real Chromium tests. The browser suite uses an owned fictional page. Its plugin UI tests simulate only the host message boundary; native renderer tests were executed separately in the actual Figma validation file. Browser tests require loopback connectivity and permission to launch Chromium.

The source benchmark measures capture structure and observed viewport differences. It does not claim Figma visual accuracy. Image comparison reports changed pixels and dimensions as diagnostics. Human cleanup-time studies and a commercial converter comparison have not been run.

## Current support

| Area | Implemented | Known limits |
|---|---|---|
| Capture | Public HTTP(S), 1–5 widths, light/dark, section selector, bounded scrolling | No signed-in browser capture, bot challenge bypass, or whole-site crawling |
| Typography | Editable styled runs, measured normal line height, underline/strikethrough, Chromium font evidence, supported variable axes, explicit substitutes | Font evidence covers up to 256 elements per viewport; mixed glyph fallback and exact browser/Figma baseline equivalence require review |
| Layout | Common flow, wrapping, simple native grid, fill/hug, border-box width limits | Grid spans/placement and reordered/reversed flex fall back to measured fixed positions; complex tracks, margins, RTL flow and transforms need review |
| Assets | Original image pixels, five object-fit modes, content-box padding and computed crop position; sanitized SVG vectors | Custom crops use editable clipping frames and require review after resizing; new native crop regression pending Figma quota |
| Foundations | Local text styles, exact observed color and spacing variables with bindings | Semantic token aliases, theme collections and existing library mapping are future work |
| Components | High-confidence repeated families, main components, instances and text properties | Rich-text variations are kept separate; state/variant recovery and cross-page reconciliation are future work |
| Responsiveness | Separate real viewport captures, observed differences, fluid native layouts where representable | Exact CSS breakpoint thresholds and automatic structure switching in Design are not promised |
| Verification | Pixel differences, overlays, geometry/text checks, real Figma edit/resize tests | No universal match score or claim that every website is fully supported |

Unsupported gradients, pseudo content, filters, dynamic media, and transformed regions are reported. Some are preserved only in the source reference rather than in the editable output. Review notices before relying on the result for a redesign.

The latest local checks cover 52 unit/API tests and 12 Chromium tests, including capture with crypto.randomUUID unavailable in the plugin UI. The image fixture compares 30 sampled browser pixels across six fit/crop cases. This verifies capture geometry; it is not a native-Figma pixel-match result. The 0.2 native run found a zero-minimum-width API error, now corrected; a rerun is pending the Figma Starter connector quota. Earlier 0.1 native evidence remains recorded separately.

## Implementation

- src/capture: bounded Chromium instrumentation, text/layout collection and asset packaging.
- src/core: versioned scene validation, repeated-family detection and observed responsive changes.
- src/service: loopback API, per-session bearer code, bounded jobs and authenticated public-only egress proxy.
- src/plugin: UI, font preflight, native renderer and component creation.
- src/quality: pixel and geometry comparison.
- fixtures: owned reference page and provenance.
- tests: unit, API, browser and native-Figma validation routines.

The local service rejects private/metadata destinations, pins validated DNS addresses for upstream connections, bounds images and requests, and isolates browser contexts. These are development safeguards; production cloud hosting, tenant authentication, persistence and a broader security review remain separate work.
