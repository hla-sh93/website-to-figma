import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { chromium } from 'playwright';
import { existsSync } from 'node:fs';
import { createLocalService } from '../../src/service/app.js';

const executablePath = [
  process.env.CHROMIUM_EXECUTABLE_PATH,
  chromium.executablePath(),
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
].find((p) => p && existsSync(p));
test('local dashboard completes a real demo capture and downloads a validated package', async () => {
  const app = await createLocalService({ port: 0 });
  const browser = await chromium.launch({ headless: true, executablePath, chromiumSandbox: true });
  try {
    const page = await browser.newPage();
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto(app.url.replace('127.0.0.1', 'localhost'));
    assert.match(await page.title(), /Hla.Sh/);
    await page.getByRole('button', { name: 'Capture owned demo' }).click();
    await page.waitForFunction(
      () => document.getElementById('status')?.textContent?.startsWith('Captured '),
      {},
      { timeout: 30000 },
    );
    assert.equal(await page.locator('#screens img').count(), 2);
    const download = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Download capture package' }).click();
    assert.equal((await download).suggestedFilename(), 'website-capture.json');
    await mkdir('output/playwright', { recursive: true });
    await page.screenshot({ path: 'output/playwright/dashboard.png', fullPage: true });
    assert.deepEqual(errors, []);
  } finally {
    await browser.close();
    await app.close();
  }
});

test('built plugin UI connects, captures, preflights fonts, and sends explicit import choices', async () => {
  const app = await createLocalService({ port: 0 });
  const browser = await chromium.launch({ headless: true, executablePath, chromiumSandbox: true });
  try {
    const page = await browser.newPage();
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto(app.url.replace('127.0.0.1', 'localhost'));
    // The UI message boundary is simulated here. Native Figma rendering is checked
    // separately in the actual Figma validation file using the identical renderer.

    const endpoint = app.url.replace('127.0.0.1', 'localhost');
    const manifest = JSON.parse(await readFile('dist/manifest.json', 'utf8'));
    assert.deepEqual(manifest.networkAccess.devAllowedDomains, ['http://localhost:4017']);
    const compiledUi = await readFile('dist/ui.html', 'utf8');
    assert.ok(compiledUi.includes('http://localhost:4017'));
    const ui = compiledUi.replaceAll('http://localhost:4017', endpoint);
    await page.setContent(ui);
    const { version } = JSON.parse(await readFile('package.json', 'utf8'));
    assert.ok(
      (await page.locator('footer').innerText()).includes('Development build · ' + version),
    );
    await page.evaluate(() => {
      Object.defineProperty(globalThis.crypto, 'randomUUID', {
        value: undefined,
        configurable: true,
      });
      (window as any).received = [];
      window.addEventListener('message', (event) => {
        const message = event.data?.pluginMessage;
        if (!message) return;
        if (message.type === 'IMPORT') (window as any).received.push(message);
        if (message.type === 'PREFLIGHT')
          window.postMessage(
            {
              pluginMessage: {
                type: 'PREFLIGHT_RESULT',
                missing: [
                  {
                    requested: 'Arial 400 normal',
                    replacement: { family: 'Inter', style: 'Regular' },
                  },
                ],
                availableFamilies: ['Inter'],
              },
            },
            '*',
          );
      });
    });
    await page.getByLabel('Session code').fill(app.token);
    await page.getByRole('button', { name: 'Connect service' }).click();
    await page.getByRole('button', { name: 'Try owned demo' }).waitFor({ state: 'visible' });
    const jobResponses: import('playwright').Response[] = [];
    page.on('response', (response) => {
      if (response.url() === endpoint + '/jobs' && response.request().method() === 'POST')
        jobResponses.push(response);
    });
    await page.getByRole('button', { name: 'Try owned demo' }).click();
    await page.waitForFunction(
      () => !document.getElementById('status')?.textContent?.includes('Checking editor fonts'),
    );
    assert.doesNotMatch(await page.locator('#status').innerText(), /randomUUID.*not a function/i);
    await page
      .getByRole('button', { name: 'Create editable design' })
      .waitFor({ state: 'visible', timeout: 30000 });
    assert.equal(jobResponses.length, 1);
    assert.match(jobResponses[0]!.request().headers()['idempotency-key']!, /^[A-Za-z0-9_-]{1,80}$/);
    const createdJob = (await jobResponses[0]!.json()) as { id: string };
    await page.waitForFunction(() =>
      document.getElementById('font-notice')?.textContent?.includes('Arial'),
    );
    assert.equal(
      await page
        .locator('#source')
        .getAttribute('src')
        .then((s) => s?.startsWith('data:image/png;base64,')),
      true,
    );
    await page.getByLabel('Allow the listed font substitutions. Wrapping may change.').check();
    await page.getByRole('button', { name: 'Create editable design' }).click();
    await page.waitForFunction(() => (window as any).received.length === 1);
    const choice = await page.evaluate(() => (window as any).received[0]);
    assert.equal(choice.allowSubstitution, true);
    assert.equal(choice.foundations, true);
    assert.equal(choice.scene.screens.length, 2);
    assert.deepEqual(errors, []);
    await page.screenshot({ path: 'output/playwright/plugin-preflight.png', fullPage: true });
    await page.getByRole('button', { name: 'Cancel', exact: true }).click();
    const retained = await fetch(app.url + '/jobs/' + createdJob.id + '/scene', {
      headers: { Authorization: 'Bearer ' + app.token },
    });
    assert.equal(
      retained.status,
      200,
      'Cancelling Figma insertion must retain the source capture for retry and comparison',
    );
    const offline = structuredClone(choice.scene);
    offline.screens.forEach((screen: { screenshot?: string }) => delete screen.screenshot);
    await page.setContent(ui);
    await page.locator('#file').setInputFiles({
      name: 'offline.json',
      mimeType: 'application/json',
      buffer: Buffer.from(JSON.stringify(offline)),
    });
    await page.locator('#review').waitFor({ state: 'visible' });
    assert.equal(await page.locator('#source-holder').isHidden(), true);
    assert.equal(await page.locator('#source').count(), 0);
  } finally {
    await browser.close();
    await app.close();
  }
});
