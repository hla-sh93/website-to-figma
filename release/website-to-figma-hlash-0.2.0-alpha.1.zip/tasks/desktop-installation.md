# Desktop installation · By Hla.Sh

The user completed Figma development-plugin creation and then replaced the original D: registration with a new registration inside the project. Current registered directory: `C:/Users/hla2-/Documents/HTML Tool/figma-registration/Website to Figma _ Hla.Sh`.

| Task | Status | Evidence |
|---|---|---|
| Locate Figma-assigned identity | Done | User screenshot and actual manifest verify replacement registration ID 1697948645810602763. Earlier D: ID 1697947928596564742 is superseded. |
| Configure assigned ID | Done | Source and compiled manifests use the new verified ID. |
| Rebuild and verify manifest entry points | Done | npm run build and typecheck pass. All three deployed files match compiled SHA256 hashes. |
| Update registered development plugin | Done | Latest backup output/desktop-registration-backup/20261030-150811771; deployed request-key compatibility fix and correct footer version. All SHA256 values match dist. Report: output/desktop-deployment.json. |
| Check local capture service | Done | Restarted after localhost fix. Authenticated health check at localhost:4017 returned ready, 0.2.0-alpha.1, Hla.Sh. Session code was not printed. |
| Run in Figma Desktop | Confirmed by user screenshot | Plugin opens and reaches the capture form after connection. |
| Complete installed-plugin smoke test | Partial; capture retry pending | Actual host exposed missing crypto.randomUUID. Fixed and locally reproduced with that method disabled; updated registered files. Native import through the installed UI still needs confirmation. |

The session has no callable work_state tools; this file tracks installation until those tools become available. The full implementation roadmap and native fidelity rerun remain open.

User-installed Figma rejected numeric loopback in devAllowedDomains. Manifest and plugin UI now use http://localhost:4017, as documented at https://developers.figma.com/docs/plugins/manifest/. The service accepts only its exact localhost and numeric loopback authorities on the bound port, while preserving bearer authentication, origin restrictions and loopback binding. The regression failed with 403 before the change and passes afterward. Full npm run check passes: 50 unit/API tests and 12 Chromium tests, formatting, TypeScript and build. Actual Figma manifest reload awaits user confirmation. The restarted service has a new session code.

Next user check: reopen Website to Figma · Hla.Sh from Figma Design's Plugins > Development menu, connect using the current dashboard session code, choose Try owned demo, review fonts and create the editable design. No additional manifest import is needed. The user's screenshot confirms opening and connecting; a successful native import through the installed UI is not claimed yet.

Request-key compatibility fix: the user's next screenshot confirms successful plugin loading and connection, then `crypto.randomUUID is not a function` on capture. Browser reproduction failed with that exact text after disabling randomUUID. The plugin now generates non-secret request deduplication keys from random bytes with a time/counter fallback when random APIs are absent or restricted; authentication remains the service-issued bearer code. The same built UI workflow passes with randomUUID unavailable and the server accepts the generated key. Full check: 52 unit/API + 12 browser tests, formatting, typecheck and build. Build footer now comes from package.json and displays 0.2.0-alpha.1. Registered files were backed up, copied and hash-verified; output/desktop-deployment.json records the latest deployment. Service restart is unnecessary for this client-only fix.
